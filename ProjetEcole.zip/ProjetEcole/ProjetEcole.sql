-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 22, 2017 at 10:27 PM
-- Server version: 5.7.17
-- PHP Version: 7.0.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ProjetEcole`
--

-- --------------------------------------------------------

--
-- Table structure for table `annonces`
--

CREATE TABLE `annonces` (
  `id` int(11) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `contenu` text NOT NULL,
  `lien` varchar(100) NOT NULL,
  `sticker` enum('false','true') NOT NULL,
  `nombreetoiles` int(11) UNSIGNED NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idimage` int(11) NOT NULL,
  `idutilisateur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `annonces`
--

INSERT INTO `annonces` (`id`, `titre`, `contenu`, `lien`, `sticker`, `nombreetoiles`, `date`, `idimage`, `idutilisateur`) VALUES
(3, 'ANNONCE 2 ', 'ANNONCE 2', 'pas de lien', 'true', 5, '2017-04-22 19:08:39', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cours`
--

CREATE TABLE `cours` (
  `id` int(11) NOT NULL,
  `titre` varchar(150) NOT NULL,
  `contenu` text NOT NULL,
  `lien` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idimage` int(11) NOT NULL,
  `idmatiere` int(11) NOT NULL,
  `idutilisateur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cours`
--

INSERT INTO `cours` (`id`, `titre`, `contenu`, `lien`, `date`, `idimage`, `idmatiere`, `idutilisateur`) VALUES
(1, 'FICHIER1', 'CONTENU FICHIER 1', 'pas de lien', '2017-04-22 18:55:35', 1, 1, 1),
(2, 'COURS 1 ', 'COURS 1', 'pas de lien', '2017-04-22 22:22:12', 5, 2, 1),
(3, 'FICHIER3', 'FICHIER3', 'pas de lien', '2017-04-22 22:52:31', 7, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `lien` varchar(150) NOT NULL DEFAULT 'inconnue.png',
  `description` varchar(150) NOT NULL DEFAULT 'pas de description',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `lien`, `description`, `date`) VALUES
(1, 'inconnue.png', 'pas de description', '2016-05-10 23:30:02'),
(2, '58fb9c274a709_Logo_Lycee.png', 'pas de description', '2017-04-22 19:08:39'),
(3, '58fbc89126b32_Logo_Lycee.png', 'pas de description', '2017-04-22 22:18:09'),
(4, '58fbc90905571_Sans titre.png', 'pas de description', '2017-04-22 22:20:09'),
(5, '58fbc98482d45_Logo_Lycee.png', '', '2017-04-22 22:22:12'),
(6, '58fbce782134d_Logo_Lycee.png', 'pas de description', '2017-04-22 22:43:20'),
(7, '58fbd09f7ff10_Sans titre.png', '', '2017-04-22 22:52:31'),
(8, '58fbd65a43ea4_Logo_Lycee.png', 'pas de description', '2017-04-22 23:16:58');

-- --------------------------------------------------------

--
-- Table structure for table `matieres`
--

CREATE TABLE `matieres` (
  `id` int(11) NOT NULL,
  `libelle` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `matieres`
--

INSERT INTO `matieres` (`id`, `libelle`) VALUES
(1, 'Français'),
(2, 'Arabe'),
(3, 'Anglais');

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `type` enum('directeur','professeur','etudiant') NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idimage` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `prenom`, `login`, `password`, `type`, `date`, `idimage`) VALUES
(1, 'jamaoui', 'mouad', 'jamaoui', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'directeur', '2016-03-25 14:49:49', 8),
(2, 'akhelij', 'mohammed', 'akhelij', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'etudiant', '2016-03-25 14:49:49', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_annonces_idutilisateur` (`idutilisateur`),
  ADD KEY `fk_annonces_idimage` (`idimage`);

--
-- Indexes for table `cours`
--
ALTER TABLE `cours`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cours_idimage` (`idimage`),
  ADD KEY `fk_cours_idimatiere` (`idmatiere`),
  ADD KEY `fk_cours_idutilisateur` (`idutilisateur`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `matieres`
--
ALTER TABLE `matieres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `fk_utilisateurs_idimage` (`idimage`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cours`
--
ALTER TABLE `cours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `matieres`
--
ALTER TABLE `matieres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `annonces`
--
ALTER TABLE `annonces`
  ADD CONSTRAINT `fk_annonces_idimage` FOREIGN KEY (`idimage`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_annonces_idutilisateur` FOREIGN KEY (`idutilisateur`) REFERENCES `utilisateurs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cours`
--
ALTER TABLE `cours`
  ADD CONSTRAINT `fk_cours_idimage` FOREIGN KEY (`idimage`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cours_idmatiere` FOREIGN KEY (`idmatiere`) REFERENCES `matieres` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_cours_idutilisateur` FOREIGN KEY (`idutilisateur`) REFERENCES `utilisateurs` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD CONSTRAINT `fk_utilisateurs_idimage` FOREIGN KEY (`idimage`) REFERENCES `images` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

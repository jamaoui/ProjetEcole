<?php 
//require_once ("config/init.php");

require_once(server."models/securite.php");

class Utilisateurs extends Securite
{
	/*
	*	LES ATTRIBUTS 
	*	
	*/
	private $id;
	private $nom;
	private $prenom;
	private $login;
	private $password;
	private $type;
	private $date;
	private $idimage;


	/*
	*	LES ACCESSEURS (GETTERS & SETTERS) 
	*	
	*/

	public function getId(){return $this->id;}public function setId($arg){ $this->id=$arg;}
	public function getNom(){return $this->nom;}public function setNom($arg){$this->nom=$arg;}
	public function getPrenom(){return $this->prenom;}public function setPrenom($arg){$this->prenom=$arg;}
	public function getLogin(){return $this->login;}public function setLogin($arg){$this->login=$arg;}
	public function getPassword(){return $this->password;}public function setPassword($arg){$this->password=$arg;}
	public function getType(){return $this->type;}public function setType($arg){$this->type=$arg;}
	public function getDate(){return $this->date;}public function setDate($arg){$this->date=$arg;}
	public function getIdImage(){return $this->idimage;}public function setIdImage($arg){$this->idimage=$arg;}

	
	/*
	*	LE CONSTRUCTEUR D'INITIALISATION 
	*	
	*/
	function __construct($id,$nom,$prenom,$login,$password,$type,$date,$idimage)
	{
		$this->setId($id);
		$this->setNom($nom);
		$this->setPrenom($prenom);
		$this->setLogin($login);
		$this->setPassword($password);
		$this->setType($type);
		$this->setDate($date);
		$this->setIdImage($idimage);
	}
}
?>

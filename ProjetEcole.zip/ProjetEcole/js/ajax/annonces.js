
/*------------------------------- ESPACE ANNONCES -------------------------*/
function voir_annonces(recherche)
{		

			if(recherche && recherche!='')
			{

				 $(document).ready(function() {
            	//CACHER LA LISTE
            	
            	$(".section2 #annonce_profile").fadeOut("slow");

                $.ajax({
                   url : 'views/annonces.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_annonces_recherche='+recherche,
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                   	//VIDER LA LISTE
                   	$("#div_annonces").empty();
                    	//AJOUTER LES ELEMENTS 
                    
                    $("#div_annonces").html(code_html);

                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                    $("#div_annonces").fadeIn("fast");

                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });
				return;
			}
            $(document).ready(function() {
            	
            	//CACHER LA LISTE
            	
            	$(".section2 #annonce_profile").fadeOut("slow");


                $.ajax({
                   url : 'views/annonces.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_annonces=true',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien

                   		//CACHER LE LOADING
                   		$("#chargement").fadeOut('slow'); 
                   	//VIDER LA LISTE
                   	$("#div_annonces").empty();
                    	//AJOUTER LES ELEMENTS 
                    
                    $("#div_annonces").html(code_html);

                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                    $("#div_annonces").fadeIn("fast");


                    //alert(code_html); 
                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });
}
function voir_annonce(id)
{
			$(document).ready(function() {
            	//CACHER LA LISTE

            	$("#div_annonces").slideUp("slow");

                $.ajax({
                   url : 'views/annonces.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_annonce='+id,
                   success : function(code_html, statut){ 
                   
                   // Si tout les choses sont bien 
                    
                   	
                    $(".section2").html(code_html);

                   
                   		//CACHER LE LOADING
                   		$("#chargement").fadeOut();
                    	//AJOUTER LES ELEMENTS 
                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });

}

/*------------------------------- FIN ANNONCE -------------------------*/
<!-- ============================= site footer ============================= -->
<footer>
	<table width="70%" style="background-color:transparent;" align="center" >
    <tr>
      <td style="border:none">
          <table>
            <tr>
              <th>ADRESSE &nbsp;</th>
              <td>Rue kadi Ahmed Bennani, Souissi, Rabat-Sale, Morocco</td>
              <td width="10%" align="center">Youtube <a class="youtube social" href="https://www.youtube.com/channel/UCUNnFmj-VIpbERooz_Znzfg"></a></td>

            </tr>
            <tr>
              <th>Tel &nbsp;</th>
              <td>05 37 75 00 29 <br> 05 37 75 39 64</td>
              <td width="10%" align="center">Twitter <a class="twitter2 social" href="https://twitter.com/jamaouimouad"></a></td>
            </tr>
            <tr>
              <th>Brève description &nbsp;</th>
              <td>Le lycée Ibn Sina est considéré comme l'un des meilleurs établissements publics grâce à ses enseignants et aux personnels administratifs</td>
              <td width="10%" align="center">Facebook <a class="facebook2 social" href="https://www.facebook.com/JamaouiMouad"></a></td>
    
            </tr>
            <tr>
              <th>Mission &nbsp;</th>
              <td>Dispenser un enseignement de qualité  pour le lycée</td>
             <td width="10%" align="center">Linkedin <a class="linkedin social" href="https://www.linkedin.com/in/mouad-jamaoui-3940a0ba"></a></td>
            </tr>
            
          </table>
      </td>
    </tr> 
  </table>
  <p style="">réalisé avec amour <span style="color:red">❤</span> 
Tous droits réservés  Lycée ibn sina <?php echo date("Y"); ?></p>

</footer>
<script src="js/imgbox.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/javascript.min.js"></script>
<script src="js/functions.js"></script>
<script  src='js/jquery.dataTables.min.js'></script>
<script src='js/dataTables.bootstrap.min.js'></script>
<script src="js/dataTables.responsive.min.js"></script>
<script src="js/responsive.bootstrap.min.js"></script>

    <script>
      $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip(); 
        lien_active();
      });

</script>

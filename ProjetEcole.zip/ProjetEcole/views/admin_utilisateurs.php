<?php

require_once ("../config/init.php");
require_once (server."config/connexion.php");
require_once(server."controllers/utilisateurs.php");
require_once(server."controllers/annonces.php");

        //AFFICHER TOUT LES Annonces
  $utilisateurs=(Cutilisateurs::tout_utilisateurs());
?>
<!--FORM AJOUTER -->
              <div id="ajouter" class="tab-pane fade in active">
                    <h3>Ajouter Une Utilisateur</h3>
                   <form id="form" class="col-md-10" enctype="multipart/form-data" method="POST" onsubmit="ajouter_utilisateur(this);admin_gestion('utilisateur');return false;">
                           <fieldset class="form-group">

                            <label for="nom">Nom</label>
                            <input type="text" autofocus class="form-control" name="nom" placeholder="Son Nom">
                            <label for="prenom">Prénom</label>
                            <input type="text" class="form-control" name="prenom" placeholder="Son Prenom">
                            <label for="login">Login</label>
                            <input type="text" class="form-control" name="login" placeholder="Son Login">
                            <label for="password">Mot de passe </label>
                            <input type="text" required  class="form-control" name="password" placeholder="Son password">
                            <hr>
                            <label class="help-block">Type de compte</label>
                            <label class="c-input c-radio">
                            <input name="type" checked value="professeur"  type="radio">
                            <span></span>
                            Professeur
                          </label>
                               <label class="c-input c-radio">
                                   <input value="directeur" name="type" type="radio">
                                   <span class="c-indicator"></span>
                                   Directeur
                               </label>
                               <label class="c-input c-radio">
                                   <input value="etudiant" name="type" type="radio">
                                   <span class="c-indicator"></span>
                                   etudiant
                               </label>
                           <label class="help-block" for="image">Image</label>
                 <input type="file" name="image" id="image">
                 <p class="help-block">si l'image n'est pas choisie il va prendre une photo anonyme que vous pouvez la modifier ensuite</p>
                          <button class="btn-block btn-lg btn btn-primary" id="btn_ajouter" type="submit">Ajouter</button>
                          <button class="btn-block btn-lg btn btn-warning" id="btn_reset" type="reset">Vider Les Champs</button>
                          </fieldset>
                        </form>
 <?php
        //s'il ne trouve aucune ressource
       
      if(count($utilisateurs[0])<=1) die();?>
  
<!--DATATABLE!-->
             <table id="Affichage_Utilisateurs"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="90%">
                <thead>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-user "></i>&nbsp;Nom</th>
                <th><i class="fa fa-user "></i>&nbsp;Prenom</th>
                <th><i class="fa fa-user "></i>Login</th>
                <th><i class="fa fa-user "></i>Type</th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date D'inscription</th>
                <th><i class="fa fa-camera-retro"></i></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                              <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-user "></i>&nbsp;Nom</th>
                <th><i class="fa fa-user "></i>&nbsp;Prenom</th>
                <th><i class="fa fa-user "></i>Login</th>
                <th><i class="fa fa-user "></i>Type</th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date D'inscription</th>
                <th><i class="fa fa-camera-retro"></i></th>
            </tr>
        </tfoot>
    </table>

    <script type="text/javascript">

         $(document).ready(function() {
                   var code_html=<?php echo json_encode($utilisateurs); ?>;
                    $('#Affichage_Utilisateurs').DataTable({
                        data:code_html,
                        columns:
                        [
                           {'data':'id',
                            'searchable':false,
                            'sortable':false,
                            'render':function(id){return "<button data-toggle='modal' data-target='#modal_modifier' class='btn btn-info btn_modifier' value='"+id+"'><i class='fa fa-pencil-square-o'></i></button>"+"<button class='btn btn-danger  btn_supprimer' value='"+id+"'><i class='fa fa-times'></i></button>";}},
                          {'data':'id'},
                          {'data':'nom'},
                          {'data':'prenom'},
                          {'data':'login'},
                          {'data':'type'},
                          {'data':'date'},
                          {'data':'lienimage','render':function(image){return "<img class='img img-responsive' width='50%' src='images/utilisateurs/"+image+"'/>";}}
                        ]
                        ,"autoFill":true,
                     "pagingType": "full_numbers",
                     "language": {
                                   "paginate": {
                                      "previous": "Prec",
                                      "first" : "début",
                                      "next": "suiv",
                                      "last":"fin"
                                    },
                        "lengthMenu": "Affichage _MENU_ lignes par page",
                        "zeroRecords": "Aucun Résultat  - ",
                        "info": "Résultat :  page _PAGE_ sur  _PAGES_ pages ",
                        "infoEmpty": "Aucun Résultat",
                        "infoFiltered": "(Filtré de _MAX_ Lignes)"
                    }
                    });
                    //Modifier
                    
                    $('.btn_modifier').click(function() {
                        var data=<?php echo json_encode($utilisateurs);?>;

                          var id=$(this).val();
                        $.each(data, function(i, item) {
                            if(item.id.toString()===id)
                            {

                              //La Copie du formulaire d'ajout
                              $('#modal_modifier_body').html('<form  id="form_modifier" method="post">'+$('#form').html()+"</form>");
                              $("#modal_modifier_body #form_modifier");
                                //Changer L'id & la valeur du button
                              $("#form_modifier #btn_ajouter").html("modifier").attr("id","btn_modifier").attr("value",id).attr("onsubmit","modifier_utilisateur($('#form_modifier #btn_modifier'));$('#gestion').fadeOut(2000);admin_gestion('utilisateur');return false;");
                              
                                //Remplissage du formulaire avec les valeurs de l'element
                                $("#form_modifier input[name='nom']").val(item.nom);
                                $("#form_modifier input[name='prenom']").val(item.prenom);
                                $("#form_modifier input[name='login']").val(item.login);

                                $("#form_modifier input[name='password']").attr("required","required");
                                $("#form_modifier input[name='password']").attr("placeholder","Nouveau Mot de Passe");
                                
                                //Ajouter L'apercu
                                $("#form_modifier *[type='file']").prev().prepend("<img  class='img img-responsive'src='images/utilisateurs/"+item.lienimage+"'/>");
                                $("#form_modifier *[type='file']").prev().prepend("<input type='hidden' name='id' value='"+item.id+"'/>");

                                //Les Radios
                                switch(item.type)
                                {
                                    case "directeur":
                                        $("#form_modifier *[name='type'][value='directeur']").attr('checked','true')
                                    break;
                                    case "professeur":
                                    ;
                                    $("#form_modifier *[name='type'][value='professeur']").attr('checked','true');
                                    break;
                                    case "etudiant":

                                        $("#form_modifier *[name='type'][value='etudiant']").attr('checked','true');
                                    break;

                                }
                              
                            }
                        });
                       
                    });
                    //SUPPRIMER
                    $('.btn_supprimer').click(function() {
                      //S'il clique sur yes
                      if(confirm("Voulez vous vraiment Supprimé cette Annonce ? "))
                      {
                        supprimer_utilisateur($(this));
                        admin_gestion("utilisateur");

                      }
                    });

              });

                 
            

</script>
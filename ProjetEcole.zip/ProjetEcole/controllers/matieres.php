<?php 
/**
*  
*/
require_once(server."models/matieres.php");
class Cmatieres extends matieres
{
	public static function ajouter_matiere($matiere)
	{
		
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		
		 $id=$matiere->setId(NULL);

		 $libelle=$matiere->getLibelle();

		 
		//PREPARATION DE LA REQUETE
		$req=$CNX->prepare("INSERT INTO matieres VALUES(:id,:libelle)");
		$req->execute(array('id'=>$id,'libelle'=>$libelle));


	}

	public static function tout_matieres()
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];

		//SECURISER LES DONNEES AVEC LA FONCTION DEJA CREE
		
		$args=(Cmatieres::securite(func_get_args()));

		//VAR POUR COMPTER LE NOMBRE DE LIGNES POUR LE RESULTAT
		$nb=0;

		//VAR POUR ENVOYER LE RESULTAT
		$resultat=[];
		

			$req=$CNX->prepare("SELECT * FROM matieres");
		
			$req->execute();

			//Nombres de lignes 
		
		 $nb=$req->rowcount();

		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		$resultat[0]['nombrematieres']=$nb;
		return $resultat;

	}
public static function modifier_matiere($matiere)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$matiere->getId();

		$libelle=$matiere->getLibelle();
		
		
		try{
		$req=$CNX->prepare("UPDATE matieres SET libelle=:libelle
								WHERE id=:id");
		
			$req->execute(array('libelle'=>$libelle,'id'=>$id));
		}catch(Exception $e){die($e->getMessage());}
		
	}

	public static function supprimer_matiere($matiere)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$matiere->getId();
		
		try{
			//Supprimer les cours de cette matiere
			$req=$CNX->prepare("DELETE FROM cours WHERE idmatiere=:id");
			$req->execute(array('id'=>$id));

			$req=$CNX->prepare("DELETE FROM matieres WHERE id=:id");
			$req->execute(array('id'=>$id));
		}catch(Exception $e){die($e->getMessage());}
	}

}

?>

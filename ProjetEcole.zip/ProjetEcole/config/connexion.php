<?php 
//CONNEXION AU SERVEUR ET A LA BASE DE DONNEES
session_start();
ob_start();


require_once ("init.php");
try
{
 $GLOBALS['cnx']= new PDO('mysql:host=localhost;dbname=ProjetEcole', 'root', 'rootroot');
 $GLOBALS['cnx']->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
 $GLOBALS['cnx']->query("set names 'utf8'");
}
catch(Exception $e) {die('Erreur : '.$e->getMessage());}

require_once(server."controllers/utilisateurs.php");

define("IS_CONNECTED",Cutilisateurs::is_connected());
?>

<?php 
  require_once ("../config/init.php");
  require_once (server."config/connexion.php");
  require_once(server."controllers/utilisateurs.php");
  require_once(server."controllers/annonces.php");
        //AFFICHER TOUT LES Annonces
  $annonces=(Cannonces::tout_annonces());
?>
<!--FORM AJOUTER -->

              <div id="ajouter" class="tab-pane fade in active">
                    <h3>Ajouter Une Annonce</h3>
                   <form id="form" class="col-md-10" enctype="multipart/form-data" method="POST" onsubmit="ajouter_annonce(this);return false;">
                          <fieldset class="form-group">

                            <label for="titre">Titre</label>
                            <textarea autofocus class="form-control" name="titre" placeholder="Titre de l'annonce" rows="1"></textarea>
                            <hr>
                            <label for="contenu">Contenu de l'annonce</label>
                            <textarea  class="form-control" name="contenu" placeholder="contenu de l'annonce" rows="4"></textarea>
                            <hr>
                            <label for="lien">Ajouter un lien externe vers un article</label>
                            <input  class="form-control" type="url" name="lien" placeholder="http://Lien vers une page" />
                            <span class="text-muted help-block"> Vous pouvez Ajouter un lien externe pour plus d'informations pour les etudiants .</span>
                          
                            <hr>

                            <label class="help-block">Mettre En Haut ? (Sticker)</label>
                            <label class="c-input c-radio">
                            <input name="sticker"   value="true"  type="radio">
                            <span></span>
                            Oui
                          </label>
                          <label class="c-input c-radio">
                            <input checked value="false" name="sticker" type="radio">
                            <span class="c-indicator"></span>
                           Non
                          </label>
                          
                          <hr>

                           <label for="nombreetoiles">Combien d'etoiles pour ce sujet ? (0-5)</label>
                            
                            <span style="color:royalblue" id="nombreetoiles"></span>
                            <input max='5' min="0" onchange="nbretoiles(this.value)"  class="form-control"  type="number" name="nombreetoiles" placeholder="Combien d'etoiles ?" />
                                <script type="text/javascript">
                                  //FONCTION POUR LES ETOILES
                                  function nbretoiles(value)
                                  {

                                    $('#nombreetoiles').empty();
                                    for(var i=1;i<=value;i++)
                                      $('#nombreetoiles').append("<i class='fa fa-star fa-1x'></i>");

                                  }
                                </script>
                              
                              <hr>
                            <label class="help-block" for="image">Image</label>

                 <input class="form-control"  type="file" name="image" id="image">
                <hr>
                <button class="btn-block btn-lg btn btn-primary" id="btn_ajouter" type="submit">Ajouter</button>
                          <button class="btn-block btn-lg btn btn-warning" id="btn_reset" type="reset">Vider Les Champs</button>
                          </fieldset>
                        </form>
 <?php
        //s'il ne trouve aucune ressource
       
      if(count($annonces[0])<=1) die();?>
  
<!--DATATABLE!-->
             <table id="Affichage_Annonces"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="90%">
                <thead>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th><i class="fa fa-user "></i>&nbsp;Nom Utilisateur</th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;Titre Annonce</th>
                <th><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp; Contenu</th>
                <th><i class="fa fa-edge" aria-hidden="true"></i>&nbsp; Lien</th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date</th>
                <th><i class="fa fa-camera-retro"></i></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th><i class="fa fa-user "></i>&nbsp;Nom Utilisateur</th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-info-circle" aria-hidden="true"></i>Titre Annonce</th>
                <th><i class="fa fa-envelope" aria-hidden="true"></i> Contenu</th>
                <th><i class="fa fa-edge" aria-hidden="true"></i> Lien</th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date</th>
                <th><i class="fa fa-camera-retro"></i></th>
            </tr>
        </tfoot>
    </table>

    <script type="text/javascript">

         $(document).ready(function() {
                   var code_html=<?php echo json_encode($annonces); ?>;
                    $('#Affichage_Annonces').DataTable({
                        data:code_html,
                        columns:
                        [
                           {'data':'idannonce',
                            'searchable':false,
                            'sortable':false,
                            'render':function(idannonce){return "<button data-toggle='modal' data-target='#modal_modifier' class='btn btn-info btn_modifier' value='"+idannonce+"'><i class='fa fa-pencil-square-o'></i></button>"+"<button class='btn btn-danger  btn_supprimer' value='"+idannonce+"'><i class='fa fa-times'></i></button>";}},
                          {'data':'nomutilisateur'},
                          {'data':'idannonce'},
                          {'data':'titreannonce','render':function(titreannonce){return titreannonce.substr(0,50)+' ...';}},
                          {'data':'contenuannonce','render':function(contenuannonce){return contenuannonce+' ...';}},
                          {'data':'lienannonce','render':function(lienannonce){if(lienannonce=='pas de lien')return '----';return "<a href='"+lienannonce+"' alt='"+lienannonce+"'><i class='fa fa-edge' aria-hidden='true'></i></a>";}},
                          {'data':'dateannonce'},
                          {'data':'lienimage','render':function(image){return "<img class='img img-responsive' width='50%' src='images/annonces/"+image+"'/>";}}

                        ]
                        ,"autoFill":true,
                     "pagingType": "full_numbers",
                     "language": {
                                   "paginate": {
                                      "previous": "Prec",
                                      "first" : "début",
                                      "next": "suiv",
                                      "last":"fin"
                                    },
                        "lengthMenu": "Affichage _MENU_ lignes par page",
                        "zeroRecords": "Aucun Résultat  - ",
                        "info": "Résultat :  page _PAGE_ sur  _PAGES_ pages ",
                        "infoEmpty": "Aucun Résultat",
                        "infoFiltered": "(Filtré de _MAX_ Lignes)"
                    }
                    });
                    //Modifier
                    
                    $('.btn_modifier').click(function() {
                        var data=<?php echo json_encode($annonces);?>;

                          var id=$(this).val();
                        $.each(data, function(i, item) {
                            if(item.idannonce.toString()===id)
                            {

                              //La Copie du formulaire d'ajout
                              $('#modal_modifier_body').html('<form  id="form_modifier" method="post">'+$('#form').html()+"</form>");
                              $("#modal_modifier_body #form_modifier");
                                //Changer L'id & la valeur du button
                              $("#form_modifier #btn_ajouter").html("modifier").attr("id","btn_modifier").attr("value",id).attr("onclick","modifier_annonce($('#form_modifier #btn_modifier'));$('#gestion').fadeOut(2000);admin_gestion('annonce');return false;");
                                
                                //Remplissage du formulaire avec les valeurs de l'element
                                $("#form_modifier textarea[name='titre']").text(item.titreannonce);
                                $("#form_modifier textarea[name='contenu']").text(item.contenuannonce);
                                
                                if(item.lienannonce!='pas de lien')
                                $("#form_modifier *[name='lien']").val(item.lienannonce);
                                
                                $("#form_modifier *[name='nombreetoiles']").val(item.nombreetoilesannonce);
                                //Appell a la fonction pour animer les etoiles
                                nbretoiles(item.nombreetoilesannonce.toString());
                                //Ajouter L'apercu
                                $("#form_modifier *[type='file']").prev().prepend("<img  class='img img-responsive'src='images/annonces/"+item.lienimage+"'/>");
                                $("#form_modifier *[type='file']").prev().prepend("<input type='hidden' name='id' value='"+item.idannonce+"'/>");

                                //Les Radios 

                                if(item.stickerannonce==='true')
                                {
                                  $("#form_modifier *[name='sticker'][value='true']").attr('checked','true');
                                  $("#form_modifier *[name='sticker'][value='false']").attr('checked','false');
                                }

                            }
                        });
                       
                    });
                    //SUPPRIMER
                    $('.btn_supprimer').click(function() {
                      //S'il clique sur yes
                      if(confirm("Voulez vous vraiment Supprimé cette Annonce ? "))
                      {
                        supprimer_annonce($(this));
                        admin_gestion("annonce");

                      }
                    });

              });

                 
            

</script>
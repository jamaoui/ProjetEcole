
/*------------------------------- ESPACE ETUDIANT PHP -------------------------*/
function voir_cours(recherche)
{		
			
      $("#chargement").fadeIn('slow');
			if(recherche && recherche!='')
			{

				 $(document).ready(function() {
            	//CACHER LA LISTE
            	
            	$(".section2 #cour_profile").fadeOut("slow");

                $.ajax({
                   url : 'views/espaceetudiants.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_cours_recherche='+recherche,
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                        //CACHER LE LOADING
                      $("#chargement").fadeOut('slow'); 
                   	//VIDER LA LISTE
                   	$("#ul").empty();
                    	//AJOUTER LES ELEMENTS 
                    
                    $("#ul").append(code_html);

                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                    $("#ul").fadeIn("fast");

                    	//RECHARGER LE SCRIPT DES IMAGES BOX
                    imgbox(); 
                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });
				return;
			}

            $(document).ready(function() {
            	
      $("#chargement").fadeIn('slow');
            	//CACHER LA LISTE
            	
            	$(".section2 #cour_profile").fadeOut('slow');


                $.ajax({
                   url : 'views/espaceetudiants.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_cours_exercices=true',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                        //CACHER LE LOADING
                      $("#chargement").fadeOut('slow'); 
                   	//VIDER LA LISTE
                   	$("#ul").empty();
                    	//AJOUTER LES ELEMENTS 
                    
                    $("#ul").append(code_html);

                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                    $("#ul").fadeIn("fast");

                    	//RECHARGER LE SCRIPT DES IMAGES BOX
                    imgbox(); 
                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });
}
function voir_cour(id)
{
	$(document).ready(function() {
              
              //CACHER LA LISTE

      $("#ul").fadeOut();      
              
      $("#chargement").fadeIn('slow');  

                $.ajax({
                   url : 'views/espaceetudiants.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'afficher_cour='+id,
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                      //AJOUTER LES ELEMENTS 
                    
                   
                    $(".section2").append(code_html);
                        //CACHER LE LOADING
                      $("#chargement").fadeOut(); 
                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
               
            });

}

/*------------------------------- FIN ESPACE -------------------------*/
<?php
require_once ("../config/init.php");

require_once(server."models/cours.php");
class Ccours extends cours
{
	public static function tout_cours($id='',$recherche='')
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];

		//SECURISER LES DONNEES AVEC LA FONCTION DEJA CREE
		
		$args=(Ccours::securite(func_get_args()));

		//VAR POUR LA SECURITE
		$i=0;
		//VAR POUR COMPTER LE NOMBRE DE LIGNES POUR LE RESULTAT
		$nb=0;

		//VAR POUR ENVOYER LE RESULTAT
		$resultat=[];
		
		//Recuperation des donnees securisee
		
		foreach (get_defined_vars() as $name=>$value)if($i<func_num_args())$$name=$args[$i++];else break;

		if(!empty($id))
		{
			$req=$CNX->prepare("SELECT utilisateurs.id as 'idutilisateur',
									   utilisateurs.nom as 'nomutilisateur',
									   utilisateurs.prenom 'prenomutilisateur',
									   
									   cours.id as 'idcour',
									   cours.titre as 'titrecour',
									   cours.contenu as 'contenucour',
									   cours.lien as 'liencour',
									   cours.date as 'datecour',

									   images.lien as 'lienimage',
									   images.description as 'descriptionimage',
									   matieres.libelle as 'libellematiere'								   
							    FROM images,cours,matieres,utilisateurs 
								
								WHERE images.id=cours.idimage
								AND   cours.id=:id
								AND   matieres.id=cours.idmatiere 
								AND   cours.idutilisateur=utilisateurs.id

								ORDER BY cours.date DESC
							  
							  ");
		
			$req->execute(array('id'=>$id));

			//Nombres de lignes 
		
		 $nb=$req->rowcount();

		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		}

		else
		{
			//VERIFICATION S'IL Y'A UNE RECHERCHE OU NON
			$recherche=(!empty($recherche))?"%".$recherche."%":"%";

			$req=$CNX->prepare("SELECT utilisateurs.id as 'idutilisateur',
									   utilisateurs.nom as 'nomutilisateur',
									   utilisateurs.prenom 'prenomutilisateur',
									   
									   cours.id as 'idcour',
									   cours.titre as 'titrecour',
									   cours.contenu as 'contenucour',
									   cours.lien as 'liencour',
									   cours.date as 'datecour',

									   images.lien as 'lienimage',
									   images.description as 'descriptionimage',

									   matieres.libelle as 'libellematiere'	
								 
								FROM images,cours,matieres,utilisateurs 	
								
								WHERE 
								(
									(
										images.id=cours.idimage
										AND   matieres.id=cours.idmatiere 
										AND   cours.idutilisateur=utilisateurs.id
									) 
									AND 
									(
										utilisateurs.nom like :recherche
										OR
										utilisateurs.prenom like :recherche
										OR
										cours.titre like :recherche
										OR
										cours.contenu like :recherche
										OR
										cours.date like :recherche
										OR
										matieres.libelle like :recherche
										OR
										images.description like :recherche
									)
								)
								ORDER BY cours.date DESC

								");
		
			$req->execute(array('recherche'=>$recherche));
			//Nombres de lignes 

		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		}

		return $resultat;

	}
	public static function modifier_cours($cours)
	{
		//RECUPERATION DE LA CONNEXION PDO
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$cours->getId();

		$titre=$cours->getTitre();
		$contenu=$cours->getContenu();
		$lien=$cours->getLien();
		$idimage=$cours->getIdImage();
		$idmatiere=$cours->getIdMatiere();

		$reqid='';
		if($idimage!='')
			$reqid=" idimage='$idimage' ,";

		$reqlien='';
		if($lien!='')
			$reqlien=" lien='$lien' ,";
		
		
		try{
		$req=$CNX->prepare("UPDATE cours 
											SET titre=:titre,
												contenu=:contenu,
												idmatiere=:idmatiere,
												$reqlien
												$reqid
												idutilisateur=:idutilisateur
											WHERE id=:id");
		
			$req->execute(
						array('contenu'=>$contenu,
								'titre'=>$titre,
								'idmatiere'=>$idmatiere,
								'id'=>$id,
								'idutilisateur'=>$_SESSION['UTILISATEUR']['id']
								)
						);
		}catch(Exception $e){die($e->getMessage());}
		
	}
		public static function supprimer_cours($cours)
	{
		//RECUPERATION DE LA CONNEXION PDO
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$cours->getId();

		
		try{
		$req=$CNX->prepare("DELETE FROM cours WHERE id=:id");
		
			$req->execute(
						array('id'=>$id));
		}catch(Exception $e){die($e->getMessage());}
		
	}
	public static function ajouter_cours($cours)
	{
		//RECUPERATION DE LA CONNEXION PDO
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees

		$titre=$cours->getTitre();
		$contenu=$cours->getContenu();
		$lien=$cours->getLien();
		$idimage=$cours->getIdImage();
		$idmatiere=$cours->getIdMatiere();

		
				try{
		$req=$CNX->prepare("INSERT INTO cours VALUES(NULL,:titre,:contenu,:lien,now(),:idimage,:idmatiere,:idutilisateur)");
		
			$req->execute(
						array(
								'titre'=>$titre,
								'contenu'=>$contenu,
								'lien'=>$lien,
								'idmatiere'=>$idmatiere,
								'idimage'=>$idimage,
								'idutilisateur'=>$_SESSION['UTILISATEUR']['id']
								)
						);
		}catch(Exception $e){die($e->getMessage());}
	}
} 
?>

<?php
  require_once("../config/init.php");
  require_once(server."config/connexion.php");
  require_once(server."controllers/utilisateurs.php");

  //SIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII GESTION IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    if(!empty($_POST['gestion']) && isset($_POST['gestion']))
    {
      //RECUPERATION DE LA GESTION
      $gestion=$_POST['gestion'];
      
      //SI GESTION EST VIDE ARRETER L'EXECUTION
      if(empty($gestion))die();
      ?>
      <!-- FENETRE MODALE POUR LA MODIFICATION-->
<div id="modal_modifier" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
        <h4 class="modal-title" id="myModalLabel">Modifier <?php echo $gestion; ?></h4>
      </div>
      <div id="modal_modifier_body" class="modal-body">
        ...
      </div>
    </div>
  </div>
</div>
<!-------------------------------------------------------------->
         <div class="tab-content">
                <h1>gestion des <?php echo $gestion; ?>s</h1>
                    <h3>(Rechercher / Modifier / Supprimer)  <?php echo $gestion ?></h3>
                     <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Attention !</strong> les <?php echo $gestion; ?>s sont  supprimées d'une façon irréversible .<i  class="fa fa-exclamation-triangle fa-2x"></i></div>
               
      <?php
      switch($gestion)
      {
      	case 'annonce';
      		      			//ANOOOOOOOOOOOOOOOOOOOOOOOOOOOOONCE
      			?>			      	
      <script type="text/javascript">
        //SCRIPT DES REGLAGES DU DATATABLE
         $(document).ready(function() {
              //CACHER LA LISTE ET LANCER LA REQUETTE
             
                $.ajax({
                   url : 'views/admin_annonces.php',
                   type : 'POST',
                   dataType : 'html',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    $("#gestion").append(code_html);
                  },
                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
             
            });
      </script>
                    <!-------------------------------->
               <?php
        break;
        
      	case 'utilisateur';
      		//UTILISATEUR--------------------------------------------------------------------
      	?>
         <script type="text/javascript">
        //SCRIPT DES REGLAGES DU DATATABLE
         $(document).ready(function() {
              //CACHER LA LISTE ET LANCER LA REQUETTE
             
                $.ajax({
                   url : 'views/admin_utilisateurs.php',
                   type : 'POST',
                   dataType : 'html',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    $("#gestion").append(code_html);
                  },
                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
             
            });
      </script>
            <?php
      	break;
      	
      	case 'matiere';
            //MAAAAAAAAAAATIEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERE
            ?>

      <script type="text/javascript">
        //SCRIPT DES REGLAGES DU DATATABLE
         $(document).ready(function() {
              //CACHER LA LISTE ET LANCER LA REQUETTE
             
                $.ajax({
                   url : 'views/admin_matieres.php',
                   type : 'POST',
                   dataType : 'html',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    $("#gestion").append(code_html);
                  },
                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
             
            });
      </script>
      <?php
      	break;
      	

      	
      	default :

      	break;
      }
      echo " </div><!--FIN DE TAB CONTENT-->"; 
    }
	//SIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII AJOUT IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    else if(isset($_GET['ajouter_utilisateur']))
    {
    	extract($_POST);
    	if(!empty($prenom) &&!empty($nom)  && !empty($login) && !empty($password) && !empty($type)  )
    	{
    		  //AJOUTER UN UTILISATEUR
    		  require_once(server."controllers/utilisateurs.php");



	        //INITIALISATION DE L'IMAGE A INCONNUE
	        $idimage=1;
	        
          if(isset($_FILES['image']) && !empty($_FILES['image']['name']))
	        {
	            require_once(server."controllers/images.php");

	            
	            $image=new Cimages("id",$_FILES['image'],"pas de description","date","utilisateurs");
	            
	            //AFFECTATION  DE L'ID DE L'IMAGE
	            $idimage=(Cimages::ajouter_image($image));
	            
           }

	        $utilisateur=new Cutilisateurs("id",$nom,$prenom,$login,$password,$type,"date",$idimage);
	        //APPELL A LA FONCTION STATIQUE D'AJOUT
	        
	        (Cutilisateurs::ajouter_utilisateur($utilisateur));
			

		?><div class="alert alert-success alert-dismissible" role="alert">
  		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  		<strong>Parfait : </strong>Le <?php echo $type; ?> <?php echo $nom; ?>  est bien ajouté .
			<a data-toggle="tab" class='btn  btn-info' href="<?php   $type.'s'.".php"; ?>">voir les <?php echo $type.'s'; ?></a>
		</div>

		<?php

    	}
    	else
    	{
    		?><div class="alert alert-warning alert-dismissible" role="alert">
  		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  		<strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
		</div>
		<?php

    	}
    }
    else if(isset($_GET['ajouter_image']) && isset($_FILES['image']))
    {
    	extract($_POST);
    	if(empty($description)) $description='pas de description';

    		  //AJOUTER UN UTILISATEUR
    		  require_once(server."controllers/utilisateurs.php");

	        
	       require_once(server."controllers/images.php");

	            
	            $image=new Cimages("id",$_FILES['image'],$description,"date","utilisateurs");
	            
	            //AFFECTATION  DE L'ID DE L'IMAGE
	            (Cimages::ajouter_image($image));
	            
   

		?><div class="alert alert-success alert-dismissible" role="alert">
  		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  		<strong>L'image </strong>est bien ajouté .
			<a data-toggle="tab" class='btn  btn-info' href="<?php   $type.'s'.".php"; ?>">voir les <?php echo $type.'s'; ?></a>
    	</div>

		<?php

    	
    }
    else if(isset($_GET['ajouter_annonce']))
    {
          //AJOUTER UNE ANNONCE
          require_once(server."controllers/annonces.php");
          
      extract($_POST);
    if(!empty($contenu) && !empty($titre) && !empty($sticker) )
      {        
          //INITIALISATION DE L'IMAGE A INCONNUE
          $idimage=1;
          
          if(empty($lien))$lien='pas de lien';
          
          if(empty($nombreetoiles))$nombreetoiles=0;

          if(isset($_FILES['image']) && !empty($_FILES['image']['name']))
          {
              require_once(server."controllers/images.php");
              
              $image=new Cimages("id",$_FILES['image'],"pas de description","date","annonces");
              
              //AFFECTATION  DE L'ID DE L'IMAGE
              $idimage=(Cimages::ajouter_image($image));
              
           }
          $annonce=new Cannonces("id",$titre,$contenu,$lien,$sticker,$nombreetoiles,"date",$idimage,'');
          
          //APPELL A LA FONCTION STATIQUE D'AJOUT

          (Cannonces::ajouter_annonce($annonce));
      

    ?><div class="alert alert-success alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>Parfait : </strong>L'annonce  <strong>  <?php echo $titre; ?> </strong>est bien ajouté .
      <a data-toggle="tab" class='btn  btn-info' href="#maj">voir les Annonces</a>
    </div>
    <script>
        $(document).ready(function(){
            admin_gestion("annonce");
          }
        );
    </script>
    <?php
      }
      else
      {
        ?><div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
    <?php

      }
}
else if(isset($_GET['ajouter_matiere']))
{
    //AJOUTER UNE ANNONCE
    require_once(server."controllers/matieres.php");

          
      extract($_POST);
    if(!empty($libelle) )
    {
          $matiere=new cmatieres("id",$libelle);
          
          //APPELL A LA FONCTION STATIQUE D'AJOUT

          (Cmatieres::ajouter_matiere($matiere));
      

    ?><div class="alert alert-success alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>Parfait : </strong>La matiere  <strong>  <?php echo $libelle; ?> </strong>est bien ajouté .
    </div>
    <?php
    }
    else
    {
      ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
      <?php
    }       
}
else if(isset($_GET['supprimer_annonce']))
{
    require_once(server."controllers/annonces.php");
        
        if(empty($_POST['supprimer_annonce'])) die("id introuvable");
        
        //Supprimer 
        
        $annonce=new Cannonces($_POST['supprimer_annonce'],'','','','','',"date",'','');
        (Cannonces::supprimer_annonce($annonce));

}
else if(isset($_GET['supprimer_utilisateur']))
{
    require_once(server."controllers/utilisateurs.php");

        
        if(empty($_POST['supprimer_utilisateur'])) die("id introuvable");
        
        //Supprimer 
        $utilisateur=new Cutilisateurs($_POST['supprimer_utilisateur'],'','','','','',"date",'');
        (Cutilisateurs::supprimer_utilisateur($utilisateur));

}
else if(isset($_GET['modifier_annonce']))
{
          //AJOUTER UNE ANNONCE
          require_once(server."controllers/annonces.php");

 
      extract($_POST);
      if(!empty($contenu) && !empty($titre) && !empty($sticker) )
      {        
          //INITIALISATION DE L'IMAGE A INCONNUE
          $idimage='';

          if(empty($lien))$lien='pas de lien';
          
          if(empty($nombreetoiles))$nombreetoiles=0;

          if(isset($_FILES['image']) && !empty($_FILES['image']['name']))
          {
              require_once(server."controllers/images.php");
              
              $image=new Cimages("id",$_FILES['image'],"pas de description","date","annonces");
              
              //AFFECTATION  DE L'ID DE L'IMAGE
              $idimage=(Cimages::ajouter_image($image));
              
           }

          $annonce=new Cannonces($id,$titre,$contenu,$lien,$sticker,$nombreetoiles,"date",$idimage,'');
          //APPELL A LA FONCTION STATIQUE D'AJOUT

          (Cannonces::modifier_annonce($annonce));
      }
      else
      {
        ?><div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
    <?php

      }
}
else if(isset($_GET['modifier_matiere']))
{
          //AJOUTER UNE ANNONCE
          require_once(server."controllers/matieres.php");

 
      extract($_POST);
      if(!empty($libelle))
      {     
          $matiere=new Cmatieres($id,$libelle);
          //APPELL A LA FONCTION STATIQUE De modification

          (Cmatieres::modifier_matiere($matiere));
      }
      else
      {
        ?><div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
    <?php

      }
}
else if(isset($_GET['supprimer_matiere']))
{
    require_once(server."controllers/matieres.php");


        
        if(empty($_POST['supprimer_matiere'])) die("id introuvable");
        
        //Supprimer 
        
        $matiere=new Cmatieres($_POST['supprimer_matiere'],'');
        (Cmatieres::supprimer_matiere($matiere));

}
else if(isset($_GET['modifier_utilisateur']))
{
          //AJOUTER UNE ANNONCE
          require_once(server."controllers/utilisateurs.php");

      extract($_POST);
     if(!empty($prenom) &&!empty($nom)  && !empty($login) && !empty($password))
      {        
          //INITIALISATION DE L'IMAGE A INCONNUE
          $idimage='';
          if(isset($_FILES['image']) && !empty($_FILES['image']['name']))
          {
              require_once(server."controllers/images.php");
              
              $image=new Cimages("id",$_FILES['image'],"pas de description","date","utilisateurs");
              
              //AFFECTATION  DE L'ID DE L'IMAGE
              $idimage=(Cimages::ajouter_image($image));
              
           }

          $utilisateur=new Cutilisateurs($id,$nom,$prenom,$login,$password,$type,"date",$idimage);
          //APPELL A LA FONCTION STATIQUE De Modification
          (Cutilisateurs::modifier_utilisateur($utilisateur));
      }
      else
      {
        ?><div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
    <?php

      }
}

?>
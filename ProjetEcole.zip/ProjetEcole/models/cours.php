<?php
//require_once ("config/init.php");
require_once(server."models/securite.php");
class Cours extends Securite
{
	/*
	*	LES ATTRIBUTS 
	*	
	*/

	private $id ;
	private $titre ;
	private $contenu ;
	private $lien;
	private $date ;
	private $idimage;
	private $idmatiere;
	private $idutilisateur ;


	/*
	*	LES ACCESSEURS (GETTERS & SETTERS) 
	*	
	*/

	public function getId(){return $this->id;}public function setId($arg){ $this->id=$arg;}
	public function getTitre(){return $this->titre;}public function setTitre($arg){$this->titre=$arg;}
	public function getContenu(){return $this->contenu;}public function setContenu($arg){$this->contenu=$arg;}
	public function getLien(){return $this->lien;}public function setLien($arg){$this->lien=$arg;}
	public function getDate(){return $this->date;}public function setDate($arg){$this->date=$arg;}
	public function getIdImage(){return $this->idimage;}public function setIdImage($arg){$this->idimage=$arg;}
	public function getIdMatiere(){return $this->idmatiere;}public function setIdMatiere($arg){$this->idmatiere=$arg;}
	public function getIdUtilisateur(){return $this->idutilisateur;}public function setIdUtilisateur($arg){$this->idutilisateur=$arg;}

	
	/*
	*	LE CONSTRUCTEUR D'INITIALISATION 
	*	
	*/
	function __construct($id,$titre,$contenu,$lien,$date,$idimage,$idmatiere,$idutilisateur)
	{
		$this->setId($id);
		$this->setTitre($titre);
		$this->setContenu($contenu);
		$this->setLien($lien);
		$this->setDate($date);
		$this->setIdImage($idimage);
		$this->setIdMatiere($idmatiere);
		$this->setIdUtilisateur($idutilisateur);
		
	}
}
?>

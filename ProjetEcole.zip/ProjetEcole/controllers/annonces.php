<?php 
/**
*  
*/
require_once(server."models/annonces.php");
class Cannonces extends annonces
{
	public static function tout_annonces($id='',$recherche='')
	{
		//RECUPERATION DE LA CONNEXION PDO
		$CNX=$GLOBALS['cnx'];

		//SECURISER LES DONNEES AVEC LA FONCTION DEJA CREE
		
		$args=(Cannonces::securite(func_get_args()));

		//VAR POUR LA SECURITE
		$i=0;
		//VAR POUR COMPTER LE NOMBRE DE LIGNES POUR LE RESULTAT
		$nb=0;

		//VAR POUR ENVOYER LE RESULTAT
		$resultat=[];
		
		//Recuperation des donnees securisee
		
		foreach (get_defined_vars() as $name=>$value)if($i<func_num_args())$$name=$args[$i++];else break;

		if(!empty($id))
		{
			$req=$CNX->prepare("SELECT 
									   utilisateurs.id as 'idutilisateur',
									   utilisateurs.nom as 'nomutilisateur',
									   utilisateurs.prenom 'prenomutilisateur',
									   
									   annonces.id as 'idannonce',
									   annonces.titre as 'titreannonce',
									   annonces.contenu as 'contenuannonce',
									   annonces.lien as 'lienannonce',
									   annonces.date as 'dateannonce',
									   annonces.nombreetoiles as 'nombreetoilesannonce',
									   annonces.sticker as 'stickerannonce',

									   images.lien as 'lienimage',
									   images.description as 'descriptionimage'

							    FROM images,annonces,utilisateurs 
								
								WHERE images.id=annonces.idimage
								AND   annonces.id=:id
								AND   annonces.idutilisateur=utilisateurs.id

								ORDER BY annonces.sticker DESC,annonces.date DESC,annonces.nombreetoiles DESC
							  
							  ");
		
			$req->execute(array('id'=>$id));

			//Nombres de lignes 
		
		 $nb=$req->rowcount();

		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		}
		else
		{
			//VERIFICATION S'IL Y'A UNE RECHERCHE OU NON
			$recherche=(!empty($recherche))?"%".$recherche."%":"%";

			$req=$CNX->prepare("SELECT
									   utilisateurs.id as 'idutilisateur',
									   utilisateurs.nom as 'nomutilisateur',
									   utilisateurs.prenom 'prenomutilisateur',
									   
									   annonces.id as 'idannonce',
									   annonces.titre as 'titreannonce',
									   annonces.contenu as 'contenuannonce',
									   annonces.lien as 'lienannonce',
									   annonces.date as 'dateannonce',
									   annonces.nombreetoiles as 'nombreetoilesannonce',
									   annonces.sticker as 'stickerannonce',


									   images.lien as 'lienimage',
									   images.description as 'descriptionimage'

							    FROM images,annonces,utilisateurs 
								
								WHERE 
								(
									(
										images.id=annonces.idimage 
										AND   annonces.idutilisateur=utilisateurs.id
									) 
									AND 
									(
										utilisateurs.nom like :recherche
										OR
										utilisateurs.prenom like :recherche
										OR
										annonces.titre like :recherche
										OR
										annonces.contenu like :recherche
										OR
										annonces.date like :recherche
										OR
										images.description like :recherche
									)
								)
								ORDER BY annonces.sticker DESC,annonces.date DESC,annonces.nombreetoiles DESC

								");
		
			$req->execute(array('recherche'=>$recherche));
			//Nombres de lignes 
			$nb=$req->rowcount();
		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		}
		$resultat[0]['nombreannonces']=$nb;
		return $resultat;

	}
	public static function ajouter_annonce($annonce)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$annonce->getId();
		$titre=$annonce->getTitre();
		$contenu=$annonce->getContenu();
		$lien=$annonce->getLien();
		$nombreetoiles=$annonce->getNombreEtoiles();
		$idimage=$annonce->getIdImage();
		$sticker=$annonce->getSticker();
		
		
		try{
		$req=$CNX->prepare("INSERT INTO annonces VALUES(NULL,:titre,:contenu,:lien,:sticker,:nombreetoiles,now(),:idimage,:idutilisateur)");
		
			$req->execute(
						array(
								'titre'=>$titre,
								'contenu'=>$contenu,
								'lien'=>$lien,
								'sticker'=>$sticker,
								'nombreetoiles'=>$nombreetoiles,
								'idimage'=>$idimage,
								'idutilisateur'=>$_SESSION['UTILISATEUR']['id']
								)
						);
		}catch(Exception $e){die($e->getMessage());}
		
	}


	public static function modifier_annonce($annonce)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$annonce->getId();

		$titre=$annonce->getTitre();
		$contenu=$annonce->getContenu();
		$lien=$annonce->getLien();
		$nombreetoiles=$annonce->getNombreEtoiles();
		$idimage=$annonce->getIdImage();
		$reqid='';
		if($idimage!='')
			$reqid=" idimage='$idimage' ,";
		$sticker=$annonce->getSticker();
		
		
		try{
		$req=$CNX->prepare("UPDATE annonces SET titre=:titre,
												contenu=:contenu,
												lien=:lien,
												sticker=:sticker,
												nombreetoiles=:nombreetoiles,
												$reqid
												idutilisateur=:idutilisateur
											WHERE id=:id");
		
			$req->execute(
						array(
								'id'=>$id,
								'titre'=>$titre,
								'contenu'=>$contenu,
								'lien'=>$lien,
								'sticker'=>$sticker,
								'nombreetoiles'=>$nombreetoiles,
								'idutilisateur'=>$_SESSION['UTILISATEUR']['id']
								)
						);
		}catch(Exception $e){die($e->getMessage());}
		
	}

	public static function supprimer_annonce($annonce)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$annonce->getId();
		
		try{
		$req=$CNX->prepare("DELETE FROM annonces WHERE id=:id");
			$req->execute(array('id'=>$id));
		}catch(Exception $e){die($e->getMessage());}
	}
} 
?>

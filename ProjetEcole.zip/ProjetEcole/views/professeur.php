<?php 
    require_once ("../config/init.php");
    require_once(server."config/connexion.php");
    require_once(server."controllers/utilisateurs.php");


  //SIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII GESTION IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    if(!empty($_POST['gestion']) && isset($_POST['gestion']))
    {
      //RECUPERATION DE LA GESTION
      $gestion=$_POST['gestion'];
      
      //SI GESTION EST VIDE ARRETER L'EXECUTION
      if(empty($gestion))die();
      ?>
      <!-- FENETRE MODALE POUR LA MODIFICATION-->
<div id="modal_modifier" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
        <h4 class="modal-title" id="myModalLabel">Modifier <?php echo $gestion; ?></h4>
      </div>
      <div id="modal_modifier_body" class="modal-body">
        ...
      </div>
    </div>
  </div>
</div>
<!-------------------------------------------------------------->
         <div class="tab-content">
                <h1>gestion des <?php echo $gestion; ?>s</h1>
                    <h3>(Rechercher / Modifier / Supprimer)</h3>
                     <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Attention !</strong> les <?php echo $gestion; ?>s sont  supprimées d'une façon irréversible .<i  class="fa fa-exclamation-triangle fa-2x"></i></div>
               
      <?php
      switch($gestion)
      {
      	case 'cour';
      		//UTILISATEUR--------------------------------------------------------------------
      	?>
         <script type="text/javascript">
        //SCRIPT DES REGLAGES DU DATATABLE
         $(document).ready(function() {
              //CACHER LA LISTE ET LANCER LA REQUETTE
             
                $.ajax({
                   url : 'views/professeur_cours.php',
                   type : 'POST',
                   dataType : 'html',
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    $("#gestion").append(code_html);
                  },
                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
             
            });
      </script>
            <?php
      	break;
 
      	
      	default :

      	break;
      }
      echo " </div><!--FIN DE TAB CONTENT-->"; 
    }
else if(isset($_GET['supprimer_cours']))
{
        require_once(server."controllers/cours.php");

        
        if(empty($_POST['supprimer_cours'])) die("id introuvable");
        
        //Supprimer 
        
        $cours=new Ccours($_POST['supprimer_cours'],'','','','','',"date",'');
        (Ccours::supprimer_cours($cours));

}
else if(isset($_GET['ajouter_cours']))
{
 
      require_once(server."controllers/cours.php");
      extract($_POST);
      if(!empty($contenu) && !empty($titre) && !empty($idmatiere) )
      {        
          //INITIALISATION DE L'IMAGE A INCONNUE
          $idimage='1';

           $lien='pas de lien';
           //Ajouter Fichier

          if(isset($_FILES['file']['name'][0]) && !empty($_FILES['file']['name'][0]))
          {

            if (move_uploaded_file($_FILES['file']["tmp_name"][0],server.'fichiers/cours/'.$_FILES['file']['name'][0]))
            $lien=$_FILES['file']['name'][0];
          }
          //Ajouter Image
          if(isset($_FILES['file']['name'][1]) && !empty($_FILES['file']['name'][1]))
          {
              require_once(server."controllers/images.php");
              //AFFECTATION  DE L'ID DE L'IMAGE
              $idimage=(Cimages:: ajouter_image_absolute("","cours",$_FILES['file']['tmp_name'][1],$_FILES['file']['name'][1]));
              
           }
          $cours=new Ccours("",$titre,$contenu,$lien,"date",$idimage,$idmatiere,'idutilisateur');
          //APPELL A LA FONCTION STATIQUE D'AJOUT
          (Ccours::ajouter_cours($cours));
         
        }
}
else if(isset($_GET['modifier_cours']))
{
      require_once(server."controllers/cours.php");
      extract($_POST);
      if(!empty($contenu) && !empty($titre) && !empty($idmatiere) )
      {        
          //INITIALISATION DE L'IMAGE A INCONNUE
          $idimage='';

          $lien='';


           //Ajouter Fichier
          if(isset($_FILES['file']['name'][0]) && !empty($_FILES['file']['name'][0]))
          {
            if (move_uploaded_file($_FILES['file']["tmp_name"][0],server.'fichiers/cours/'.$_FILES['file']['name'][0]))
            $lien=$_FILES['file']['name'][0];
          }
          //Ajouter Image
          if(isset($_FILES['file']['name'][1]) && !empty($_FILES['file']['name'][1]))
          {
              require_once(server."controllers/images.php");
              //AFFECTATION  DE L'ID DE L'IMAGE
              $idimage=(Cimages:: ajouter_image_absolute("","cours",$_FILES['file']['tmp_name'][1],$_FILES['file']['name'][1]));
              
           }
          $cours=new Ccours($id,$titre,$contenu,$lien,"date",$idimage,$idmatiere,'idutilisateur');
          //APPELL A LA FONCTION STATIQUE D'AJOUT
          (Ccours::modifier_cours($cours));
      }
      else
      {
        ?><div class="alert alert-warning alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <strong>champ non renseigné!</strong>Vous devez remplir tout les champs , Merci .
    </div>
    <?php
      }
}

?>
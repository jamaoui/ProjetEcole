
/*------------------------------- ESPACE ADMIN -------------------------*/
function admin_gestion(gestion)
{
  $('li button').css("background-color",'').css("margin-left",'0');
  $('#'+gestion ).css("background-color",'royalblue');
  $('li button' ).css("border","4px outset lightblue");
  $('#'+gestion ).css("border","4px inset royalblue");


    $(document).ready(function() {
              
              //CACHER LA LISTE ET LANCER LA REQUETTE
              
              $("#gestion").fadeOut(100,'swing',function(){

                $.ajax({
                   url : 'views/admin.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'gestion='+gestion,
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    //VIDER LA LISTE
                   $("#gestion").empty();
                      //AJOUTER LES ELEMENTS 
                    $("#gestion").html(code_html);
                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                     $("#gestion").fadeIn("slow",'linear');

                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
              });

               
            });
}
function professeur_gestion(gestion)
{
  $('li button').css("background-color",'').css("margin-left",'0');
  $('#'+gestion ).css("background-color",'royalblue');
  $('li button' ).css("border","4px outset lightblue");
  $('#'+gestion ).css("border","4px inset royalblue");


    $(document).ready(function() {
              
              //CACHER LA LISTE ET LANCER LA REQUETTE
              
              $("#gestion").fadeOut(100,'swing',function(){

                $.ajax({
                   url : 'views/professeur.php',
                   type : 'POST',
                   dataType : 'html',
                   data : 'gestion='+gestion,
                   success : function(code_html, statut){ 
                   // Si tout les choses sont bien 
                    //VIDER LA LISTE
                   $("#gestion").empty();
                      //AJOUTER LES ELEMENTS
                    $("#gestion").html(code_html);
                    //AFFICHER LA LISTE APRES LE CHARGEMENT
                     $("#gestion").fadeIn("slow",'linear');

                   },

                   error : function(resultat, statut, erreur){
                    // S'il y a une erreur
                    alert("Erreur veuillez contacter Les WebMasters");
                   }
                });
              });

               
            });
}
function ajouter_utilisateur()
{
  $(document).ready(function () {

        var formData = new FormData($("#form")[0]);
        $("#btn_ajouter").html(" <i  style='color:white;' class='fa fa-cog  fa-spin  '></i> &nbsp;Ajout En cours ...");
                

        $("#btn_ajouter").attr('disabled','disabled');

        $.ajax({
            type:'POST',
            url: 'views/admin.php?ajouter_utilisateur',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                      $("#btn_ajouter").removeAttr('disabled');
                      $("#btn_ajouter").html("Ajouter");
                      
                      $("#form").fadeOut(1300,'swing',function(){
                        $("#form fieldset").prepend(data);
                      $("#form").fadeIn(1300,'linear');
                      });
                      
                      

            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
       
    });


            });

}

function ajouter_cours()
{
  $(document).ready(function () {

        var formData = new FormData($("#form")[0]);
        $("#btn_ajouter").html(" <i  style='color:white;' class='fa fa-cog  fa-spin  '></i> &nbsp;Ajout En cours ...");
        $("#btn_ajouter").attr('disabled','disabled');

        $.ajax({
            type:'POST',
            url: 'views/professeur.php?ajouter_cours',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                      $("#btn_ajouter").removeAttr('disabled');
                      $("#btn_ajouter").html("Ajouter");
                      
                      $("#form").fadeOut(1300,'swing',function(){
                        $("#form fieldset").prepend(data);
                      $("#form").fadeIn(1300,'linear');
                      });
                      
                      

            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
       
    });


            });

}
function ajouter_image()
{
  $(document).ready(function () {

        var formData = new FormData($("#form")[0]);
        $("#btn_ajouter").html(" <i  style='color:white;' class='fa fa-cog  fa-spin  '></i> &nbsp;Ajout En cours ...");
                

        $("#btn_ajouter").attr('disabled','disabled');

        $.ajax({
            type:'POST',
            url: 'views/admin.php?ajouter_image',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                      $("#btn_ajouter").removeAttr('disabled');
                      $("#btn_ajouter").html("Ajouter");
                      
                      $("#form").fadeOut(1300,'swing',function(){
                        $("#form fieldset").prepend(data);
                      $("#form").fadeIn(1300,'linear');
                      });

            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
       
    });


            });

}

function ajouter_annonce()
{
  $(document).ready(function () {

        var formData = new FormData($("#form")[0]);
        $("#btn_ajouter").html(" <i  style='color:white;' class='fa fa-cog  fa-spin  '></i> &nbsp;Ajout En cours ...");
                

        $("#btn_ajouter").attr('disabled','disabled');

        $.ajax({
            type:'POST',
            url: 'views/admin.php?ajouter_annonce',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                      $("#btn_ajouter").removeAttr('disabled');
                      $("#btn_ajouter").html("Ajouter");
                      
                      $("#form").fadeOut(1300,'swing',function(){
                        $("#form fieldset").prepend(data);
                      $("#form").fadeIn(1300,'linear');
                      });
            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
       
    });


            });

}
function ajouter_matiere()
{   
       
  $(document).ready(function () {

        var formData = new FormData($("#form")[0]);
        $("#btn_ajouter").html(" <i  style='color:white;' class='fa fa-cog  fa-spin  '></i> &nbsp;Ajout En cours ...");
                

        $("#btn_ajouter").attr('disabled','disabled');

        $.ajax({
            type:'POST',
            url: 'views/admin.php?ajouter_matiere',
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
                      $("#btn_ajouter").removeAttr('disabled');
                      $("#btn_ajouter").html("Ajouter");
                      
                      $("#form").fadeOut(1300,'swing',function(){
                        $("#form fieldset").prepend(data);
                      $("#form").fadeIn(1300,'linear');
                      });

            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
       
    });


            });

}

function supprimer_annonce(arg)
{

        $(arg).attr('disabled','disabled').siblings().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i><span class="sr-only">Loading...</span>');
       
        
        //LANCER LA REQUETTE DE SUPPRESSION

        $.ajax({
            type:'POST',
            url: 'views/admin.php?supprimer_annonce',
            data:'supprimer_annonce='+$(arg).val(),
            success:function(code_html){
                
                //ARRIVER A LA LIGNE A SUPPRIMER
                arg.parent().parent().fadeOut();
            },
            error: function(code_html){
                console.log("error");
                console.log(code_html);
            }
       
    });
}

function supprimer_cours(arg)
{

        $(arg).attr('disabled','disabled').siblings().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i><span class="sr-only">Loading...</span>');
       
        
        //LANCER LA REQUETTE DE SUPPRESSION
          $.ajax({
            type:'POST',
            url: 'views/professeur.php?supprimer_cours',
            data:'supprimer_cours='+$(arg).val(),
            success:function(code_html){
                
                //ARRIVER A LA LIGNE A SUPPRIMER
                arg.parent().parent().fadeOut();
            },
            error: function(code_html){
                console.log("error");
                console.log(code_html);
            }
       
    });
}

function supprimer_utilisateur(arg)
{

        $(arg).attr('disabled','disabled').siblings().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i><span class="sr-only">Loading...</span>');
       
        
        //LANCER LA REQUETTE DE SUPPRESSION

        $.ajax({
            type:'POST',
            url: 'views/admin.php?supprimer_utilisateur',
            data:'supprimer_utilisateur='+$(arg).val(),
            success:function(code_html){
                
                //ARRIVER A LA LIGNE A SUPPRIMER
                arg.parent().parent().fadeOut();
            },
            error: function(code_html){
                console.log("error");
                console.log(code_html);
            }
       
    });
}

function supprimer_matiere(arg)
{

        $(arg).attr('disabled','disabled').siblings().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i><span class="sr-only">Loading...</span>');
       
        //LANCER LA REQUETTE DE SUPPRESSION
    if(confirm("Attention La Suppression de cette Matiere va supprimé aussi tout ces cours !! Dernier Avertissement : voules vous supprimer ??"))
    {
        $.ajax({
            type:'POST',
            url: 'views/admin.php?supprimer_matiere',
            data:'supprimer_matiere='+$(arg).val(),
            success:function(code_html){
                
                //ARRIVER A LA LIGNE A SUPPRIMER
                arg.parent().parent().fadeOut();
            },
            error: function(code_html){
                console.log("error");
                console.log(code_html);
            }
       
    });
    }
}

function modifier_utilisateur(arg)
{
        $(arg).attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i>Modification En cours ...');
         var form=$(arg).parent().parent();
         var formData = new FormData(form[0]);
        //LANCER LA REQUETTE DE Modification
      $.ajax({
                type:'POST',
                url: 'views/admin.php?modifier_utilisateur',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){ 
                //Cacher La Fenetre Modal
                if(data=='')
                  $('#modal_modifier').modal('hide');
                else
                  alert("Erreur :vous devez remplir le  mot de passe");
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
           
        });
      return false;
}

function modifier_annonce(arg)
{

        $(arg).attr('disabled','disabled').next().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i>Modification En cours ...<span class="sr-only">Loading...</span>');
       
        //LANCER LA REQUETTE DE Modification
         var formData = new FormData($("#form_modifier")[0]);
       
      $.ajax({
                type:'POST',
                url: 'views/admin.php?modifier_annonce',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){ 
                //Cacher La Fenetre Modal
                $('#modal_modifier').modal('hide');
                
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
           
        });
      return false;
}

function modifier_cours(arg)
{

        $(arg).attr('disabled','disabled').next().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i>Modification En cours ...<span class="sr-only">Loading...</span>');
       
        //LANCER LA REQUETTE DE Modification
         var formData = new FormData($("#form_modifier")[0]);
       
      $.ajax({
                type:'POST',
                url: 'views/professeur.php?modifier_cours',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){ 
                //Cacher La Fenetre Modal
                $('#modal_modifier').modal('hide');
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
           
        });
      return false;
}

function modifier_matiere(arg)
{

        $(arg).attr('disabled','disabled').next().attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i>Modification En cours ...<span class="sr-only">Loading...</span>');
       
        //LANCER LA REQUETTE DE Modification
         var formData = new FormData($("#form_modifier")[0]);
       
      $.ajax({
                type:'POST',
                url: 'views/admin.php?modifier_matiere',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){ 
                //Cacher La Fenetre Modal
                $('#modal_modifier').modal('hide');
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
           
        });
      return false;
}

/*------------------------------- FIN ANNONCE -------------------------*/
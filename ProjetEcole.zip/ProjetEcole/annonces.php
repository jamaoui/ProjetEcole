<!DOCTYPE html>
<html lang="en">

<head>
    <title>Nos Annonces</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="icon" type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">

</head>
<body>
    <?php include( "include/nav.php"); ?>
            <?php  
                require_once($_SERVER['DOCUMENT_ROOT']."/ProjetEcole/controllers/annonces.php");
                $annonces=(Cannonces::tout_annonces());
            ?>
                       
    <!-- ============================= site section1 ============================= -->
    <div class="section1" style="background: url('images/osp-bg.png');background-size: 100% 120%;background-repeat: no-repeat;">
        <p class="section1-txt">Nos Annonces </p>
        <p align="center">
              <input id='chercher' autofocus placeholder="Professeur , Matiere ,Cours ..." class="main-search-box" style="padding:0% 1% 0% 4%;box-size:border-box;" list='datalist'/>
              <datalist  id="datalist"></datalist>  
          
                  </p>
                        <!-- FENETRE MODALE POUR LA MODIFICATION-->
<div id="modal_modifier" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;  </button>
        <h4 class="modal-title" id="myModalLabel">Modifier Annonce</h4>
        <hr>
      <div id="modal_modifier_body" class="modal-body">
        <form id="form_modifier" class="col-md-12" enctype="multipart/form-data" method="POST">
                          

                            <label for="titre">Titre</label>
                            <textarea autofocus class="form-control" name="titre" placeholder="Titre de l'annonce" rows="1"></textarea>
                            <hr>
                            <label for="contenu">Contenu de l'annonce</label>
                            <textarea  class="form-control" name="contenu" placeholder="contenu de l'annonce" rows="4"></textarea>
                            <hr>
                            <label for="lien">Ajouter un lien externe vers un article</label>
                            <input  class="form-control" type="url" name="lien" placeholder="http://Lien vers une page" />
                            <span class="text-muted help-block"> Vous pouvez Ajouter un lien externe pour plus d'informations pour les etudiants .</span>
                          
                            <hr>

                            <label class="help-block">Mettre En Haut ? (Sticker)</label>
                            <label class="c-input c-radio">
                            <input name="sticker"   value="true"  type="radio">
                            <span></span>
                            Oui
                          </label>
                          <label class="c-input c-radio">
                            <input checked value="false" name="sticker" type="radio">
                            <span class="c-indicator"></span>
                           Non
                          </label>
                          
                          <hr>

                           <label for="nombreetoiles">Combien d'etoiles pour ce sujet ? (0-5)</label>
                            
                            <span style="color:royalblue" id="nombreetoiles"></span>
                            <input max='5' min="0" onchange="nbretoiles(this.value)"  class="form-control"  type="number" name="nombreetoiles" placeholder="Combien d'etoiles ?" />
                                    <script type="text/javascript">
                                        //FONCTION POUR LES ETOILES
                                        function nbretoiles(value)
                                        {

                                            $('#nombreetoiles').empty();
                                            for(var i=1;i<=value;i++)
                                                $('#nombreetoiles').append("<i class='fa fa-star fa-1x'></i>");
                                        }
                                    </script>
                                
                              <hr>
                            <label class="help-block" for="image">Image</label>
                            <p id="image"></p>
                           <input class="form-control"  type="file" name="image" id="image">
                          <hr>
                          <button class="btn-block btn-lg btn btn-primary" id="btn_modifier" type="submit">Modifier</button> 
                        </form>
      
      </div>
      </div>
    </div>
  </div>
</div>
<!-------------------------------------------------------------->
    </div>
        <!-- FENETRE MODALE POUR LA MODIFICATION-->
                  

<!-------------------------------------------------------------->


    <!-- ============================= site section2 ============================= -->
          
        <div style="background-color:white" class="col-md-12">
        <br>
          <div style="background-color:white" id="div_annonces" >
          </div>
        <br>
        </div>
    <div class="for-section2">

        <div class="section2">
            <h1><center id="chargement"  ><i  style="color:royalblue;" class="fa fa-refresh fa-spin  fa-5x"></i></center>
        &nbsp;
        </h1>
        </div>


    </div>

    <?php include( "include/footer.php") ?>
    <script src="js/ajax/annonces.js"></script>
    <script src="js/ajax/admin.js"></script>
    <!--APPELL A LA FONCTION POUR APPORTER LES ANNONCES-->

    <script type="text/javascript">
        $(document).ready(function() {         
            voir_annonces();
            //APPELER LA FONCTION DE RECHERCHE !
            $("#chercher").keyup(function() {
                var data = $(this).val();
                voir_annonces(data);

            });
            $("#chercher").on("input",(function() {
                var data = $(this).val();
                voir_annonces(data);

            }));
        });
    </script>

<script type="text/javascript">
                             //Preparer La requette de modification
                             $('#form_modifier #btn_modifier').click(function() {
                                  modifier_annonce($(this));
                              var id=($("#chargement_modification").parent().find('.btn_modifier').val());
                            $("#chargement_modification").addClass("fa-spin");
                             
                          
                            $($(this)).delay(4000).queue(function() {
                                $("#form_modifier #btn_modifier").removeAttr("disabled");
                                $("#form_modifier #btn_modifier").html('Modifier');
                                voir_annonces();
                                
                                $("#div_annonces").delay(1000).queue(function() {
                                            //SELECTIONNER L'ENREGISTREMENT ET LE STYLISER
                             $("#div_annonces *[value="+id+"]").parent().parent().parent().parent().parent().css("background-color","aliceblue");
                            $("html, body").animate({ scrollTop: $(".btn_modifier[value="+id+"]").parent().parent().parent().parent().parent().offset().top }, 1000);  
                            
                            });
                                
                            });
        
                              return false;
                             });

                 
            
</script>

<script type="text/javascript">
                             //Preparer La requette de modification
                             $('#form_modifier #btn_modifier').click(function() {
                                  modifier_annonce($(this));
                              var id=($("#chargement_modification").parent().find('.btn_modifier').val());
                            $("#chargement_modification").addClass("fa-spin");
                             
                          
                            $($(this)).delay(4000).queue(function() {
                                $("#form_modifier #btn_modifier").removeAttr("disabled");
                                $("#form_modifier #btn_modifier").html('Modifier');
                                voir_annonces();
                                
                                $("#div_annonces").delay(1000).queue(function() {
                                            //SELECTIONNER L'ENREGISTREMENT ET LE STYLISER
                             $("#div_annonces *[value="+id+"]").parent().parent().parent().parent().parent().css("background-color","aliceblue");
                            $("html, body").animate({ scrollTop: $(".btn_modifier[value="+id+"]").parent().parent().parent().parent().parent().offset().top }, 1000);  
                            
                            });
                                
                            });
        
                              return false;
                             });
            
</script>
</body>

</html>

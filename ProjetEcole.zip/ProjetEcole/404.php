<!DOCTYPE HTML>
<html>
	<head>
	  <title></title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/css.min.css">
	  <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" href="css/normalize.css">
	  <link rel="icon" type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">
	  
	</head>
<body>
	<?php include("include/nav.php"); ?>

<!-- ============================= site section1 ============================= -->
<div class="section1" style="background: url('images/home-bg.jpg');background-size: cover;background-repeat: no-repeat;">
	<p class="section1-txt">Le Lycée <strong>Ibn Sina</strong> : un lycée public marocain
							 est un label national nourri par l’esprit d’une longue tradition de rigueur et de distinction
	<br><br></p>
	<div align="center"><input type="text" class="main-search-box" value="vous cherchez quelque chose? ..." onblur="if(this.value=='')this.value=this.defaultValue;" onfocus="if(this.value==this.defaultValue)this.value=''"></div>
</div>
<!-- ============================= site section 2 ============================= -->
&lt;<div class="for-section2">
<div class="section2" align="center">
	<p align="center">
</p><h1 align="center" style="
    font-size: 100px;
    text-shadow: 1px 1px 10px #000000;
    color: white;
">
404
</h1>
<h1 align="center" style="
    padding: 40px;
    background: #E2E2E2;
    border: 1px solid #BBB;
    border-radius: 2px 2px 2px 2px;">Oooops! la page n'est pas trouvée ,<a href="index.php">Revenir à l'index</a></h1>	<p></p>
        	
	
</div><p></p>
</div>	

<?php include("include/footer.php") ?>

</body></html>
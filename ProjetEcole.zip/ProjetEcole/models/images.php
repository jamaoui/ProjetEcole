<?php
//require_once ("config/init.php");
require_once(server."models/securite.php");
class Images extends Securite
{
	/*
	*	LES ATTRIBUTS 
	*	
	*/

	private $id ;
	private $lien ;
	private $description ;
	private $date ;
	private $chemin;

	/*
	*	LES ACCESSEURS (GETTERS & SETTERS) 
	*	
	*/

	public function getId(){return $this->id;}public function setId($arg){ $this->id=$arg;}
	public function getLien(){return $this->lien;}public function setLien($arg){$this->lien=$arg;}
	public function getDescription(){return $this->description;}public function setDescription($arg){$this->description=$arg;}
	public function getDate(){return $this->date;}public function setDate($arg){$this->date=$arg;}
	public function getChemin(){return $this->chemin;}public function setChemin($arg){$this->chemin=$arg;}

	
	/*
	*	LE CONSTRUCTEUR D'INITIALISATION 
	*	
	*/
	function __construct($id,$lien,$description,$date,$chemin)
	{
		$this->setId($id);
		$this->setLien($lien);
		$this->setDescription($description);
		$this->setDate($date);
		$this->setChemin($chemin);

	}
}
?>

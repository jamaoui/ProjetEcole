
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Espace Etudiants</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="icon" type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
  </head>
<body>

  <?php include("include/nav.php"); ?>
  <!-- ============================= site section1 ============================= -->
<div class="section1" style="background: url('images/books-bg.jpg');background-size:  100% 120%;;background-repeat: no-repeat;">
	<p class="section1-txt">Des cours proposé par les enseignants du lycée <strong>IBN SINA</strong> : Informatique , Physique , Mathématiques , ...</p>
	<p align="center">
  <input id='chercher' list='datalist' style="padding:0% 1% 0% 4%;box-size:border-box;" autofocus  placeholder="Professeur , Matiere ,Cours ..." class="main-search-box"/></p>
  <datalist  id="datalist"></datalist>  
          
</div>
<!-- ============================= site section2 ============================= -->
<div class="for-section2">
  <div class="section2">
    <h1>
       <center id="chargement"  ><i  style="color:royalblue;" class="fa fa-refresh fa-spin  fa-5x"></i></center>
    &nbsp;
    </h1>
       <ul id="ul">
        
      </ul>
  </div>
</div>

<?php include("include/footer.php") ?>


<script src="js/ajax/espaceetudiants.js"></script>
<!--APPELL A LA FONCTION POUR APPORTER LES COURS ET LES EXERCICES-->

<script type="text/javascript">
$(document).ready(function () {
//APPELER LA FONCTION D'IMPORTATION -- PREMIER APPELL !
  voir_cours();
//APPELER LA FONCTION DE RECHERCHE !
$( "#chercher").keyup(function() {
    var data=$(this).val();
     voir_cours(data);
});
$("#chercher").on("input",(function() {
                var data = $(this).val();
                voir_cours(data);

  }));
});

</script>

</body>
</html>

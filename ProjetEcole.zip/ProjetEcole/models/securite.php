<?php
	
	abstract class Securite{

	/**
	 * Class Constructor
	 */
	
	public function __construct()
	{
		
	}

	//FONCTION DE CONNEXION D'UN PROF OU D'UN ADMINISTRATEUR

	public static function securite($args)
	{

		// Eliminer Les Failles XSS
		foreach ($args as $key => $value) $args[$key]= htmlspecialchars($args[$key]);
		
		return $args;

	}

}
?>
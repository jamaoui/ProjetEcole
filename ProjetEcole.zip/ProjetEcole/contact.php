<!DOCTYPE HTML>
<html>
	<head>
	  <title>Nous Contacter</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="css/css.min.css">
	  <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" href="css/normalize.css">
	  <link rel="icon" type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">
	  
	</head>
<body>
	<?php include("include/nav.php"); ?>
<!-- ============================= site section1 ============================= -->
<div class="section1" style="background: url('images/osp-bg.png');background-size:  100% 120%;;background-repeat: no-repeat;">
<br><br><br>	<p class="section1-txt">Le Lycée <strong>Ibn Sina</strong> : un lycée public marocain
							 est un label national nourri par l’esprit d’une longue tradition de rigueur et de distinction
	<br><br></p>
</div>
<!-- ============================= site section 2 ============================= -->
&lt;<div class="for-section2">
<div class="section2" align="center">
	<p align="center">
</p><h1 align="center" style="
    font-size: 5rem;
    text-shadow: 1px 1px 10px #000000;
    color: white;
">
Contact
</h1>
<h1 align="center" style="
    padding: 40px;
    background: rgba(255,255,255,1);
    border: 1px solid #BBB;
    border-radius: 2px 2px 2px 2px;">
   Rue kadi Ahmed Bennani, Souissi
Souissi, Rabat-Sale, Morocco<br>
05 37 75 00 29 <br> 05 37 75 39 64
</h1>	<p></p>
    <div class="table-responsive">
     <table  class='table table-responsive'  style="overflow:hidden;background-color:white;border:lightgray 2px solid;" align="center" >
    <tr>
      <td>
          <table class="table-responsive">
            <tr>
              <th colspan="3" align="center"> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3308.341136370339!2d-6.840328518294507!3d33.98377043179589!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0000000000000000%3A0x299d101f6fc15e6d!2sLyc%C3%A9e+Ibn+Sina!5e0!3m2!1sfr!2s!4v1458844499274"frameborder="0" style="border:0" width="100%"allowfullscreen></iframe></th>
            </tr>
            <tr>
              <th>ADRESSE &nbsp;</th>
              <td>Rue kadi Ahmed Bennani, Souissi, Rabat-Sale, Morocco</td>
              <td width="10%" align="center">Youtube <a class="youtube social" href="https://www.youtube.com/channel/UCUNnFmj-VIpbERooz_Znzfg"></a></td>

            </tr>
            <tr>
              <th>Tel &nbsp;</th>
              <td>05 37 75 00 29 <br> 05 37 75 39 64</td>
              <td width="10%" align="center">Twitter <a class="twitter2 social" href="https://twitter.com/jamaouimouad"></a></td>
            </tr>
            <tr>
              <th>Brève description &nbsp;</th>
              <td>Le lycée Ibn Sina est considéré comme l'un des meilleurs établissements publics grâce à ses enseignants et aux personnels administratifs</td>
              <td width="10%" align="center">Facebook <a class="facebook2 social" href="https://www.facebook.com/JamaouiMouad"></a></td>
    
            </tr>
            <tr>
              <th>Mission &nbsp;</th>
              <td>Dispenser un enseignement de qualité aussi bien pour le collège que pour le lycée</td>
             <td width="10%" align="center">Linkedin <a class="linkedin social" href="https://www.linkedin.com/in/mouad-jamaoui-3940a0ba"></a></td>
            </tr>
            <tr>
              <th>Horaire &nbsp;</th>
              <td>lun-jeu:  
                  08:00 - 17:00<br>
                  ven-sam:  
                  08:00 - 12:00
              </td>
              <td></td>
            </tr>
            <tr>
              <th>Maintenant&nbsp;</th>
              <td>
              <?php
                  //TEST SI LE LYCEE EST OUVERT OU NON
                  $h=date("H");
                  if($h<17 AND $h>=8)
                    echo "<span style='border-radius:10px;width:10px;height:10px;background-color:darkgreen;display:block'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>Ouvert";
                  else
                    echo "<span style='border-radius:10px;width:10px;height:10px;background-color:darkred;display:block'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>fermée";
                  
               ?>
              </td>
              <td></td>
            </tr>
          </table>
      </td>
    </tr> 
  </table>
  </div>
	
</div><p></p>
</div>	


<?php include("include/footer.php") ?>

</body></html>
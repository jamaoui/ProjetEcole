<?php
//require_once ("config/init.php");
require_once(server."models/securite.php");
class Matieres extends Securite
{
	/*
	*	LES ATTRIBUTS 
	*	
	*/

	private $id ;
	private $libelle ;

	/*
	*	LES ACCESSEURS (GETTERS & SETTERS) 
	*	
	*/

	public function getId(){return $this->id;}public function setId($arg){ $this->id=$arg;}
	public function getLibelle(){return $this->libelle;}public function setLibelle($arg){$this->libelle=$arg;}

	
	/*
	*	LE CONSTRUCTEUR D'INITIALISATION 
	*	
	*/
	function __construct($id,$libelle)
	{
		$this->setId($id);
		$this->setLibelle($libelle);

	}
}
?>

<?php
    require_once ("../config/init.php");
    require_once(server."config/connexion.php");
    require_once(server."controllers/utilisateurs.php");
    require_once(server."controllers/cours.php");
    require_once(server."controllers/matieres.php");

  $cours=(Ccours::tout_cours());
  $matieres=(Cmatieres::tout_matieres());
?>
            <div id="ajouter" class="tab-pane fade in active">
                    <h3>Ajouter Un Cours</h3>
                   <form id="form" enctype="multipart/form-data" class="col-md-10" onsubmit="ajouter_cours(this);professeur_gestion('cour');return false;" method="POST" >
                          <fieldset class="form-group">

                          <label for="titre">Titre  : </label>
                          <input class="form-control" autofocus  type="text" name="titre" id="titre">
                          <hr>
                          <label for="contenu">contenu  : </label>
                          <textarea class="form-control"  name="contenu" id="contenu" rows="10" style="resize:none"></textarea>
                          <hr>
                          <label for="lien">Fichier Joint  : </label>
                          <input class="form-control" type="file" name="file[]" id="lien">
                          <hr>
                          <label for="image">Image Du Cours  : </label>
                          <input class="form-control" type="file" name="file[]" id="image">
                          <hr>
                          <label for="idimatiere">Votre Cours est destiné pour quelle Matiere ? </label>
                          <!--LISTE DES MATIERES-->
                          <select class="form-control"  name="idmatiere" id="idimatiere">
                              <option value=""></option>
                              <?php foreach ($matieres as $key => $value): ?>
                                  <option value="<?php echo $value['id']; ?>"><?php echo $value['libelle']; ?></option>
                              <?php endforeach ?>
                          </select>
                          <hr>


                <button class="btn-block btn-lg btn btn-primary" id="btn_ajouter" type="submit">Ajouter</button>
                          <button class="btn-block btn-lg btn btn-warning" id="btn_reset" type="reset">Vider Les Champs</button>
                          </fieldset>
                  </form>
                    <!-------------------------------->
       <?php
        //s'il ne trouve aucune ressource
      if(count($cours)==0) die();?>
  
<!--DATATABLE!-->
             <table id="Affichage_Cours"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="90%">
                <thead>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i aria-hidden="true"></i>&nbsp;Titre du Cours</th>
                <th><i  aria-hidden="true"></i>&nbsp;Contenu</th>
                <th><i class="fa fa-file-o" aria-hidden="true"></i> Fichier </th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date</th>
                <th><i class="fa fa-camera-retro"></i></th>
                <th><i  aria-hidden="true"></i>&nbsp;Matiere</th>
                <th><i class="fa fa-user " aria-hidden="true"></i></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i aria-hidden="true"></i>&nbsp;Titre du Cours</th>
                <th><i  aria-hidden="true"></i>&nbsp;Contenu</th>
                <th><i class="fa fa-file-o" aria-hidden="true"></i> Fichier </th>
                <th><i class="fa fa-calendar" aria-hidden="true"></i>&nbsp;Date</th>
                <th><i class="fa fa-camera-retro"></i></th>
                <th><i  aria-hidden="true"></i>&nbsp;Matiere</th>
                <th><i class="fa fa-user " aria-hidden="true"></i></th>
            </tr>
        </tfoot>
    </table>
    <script type="text/javascript">

         $(document).ready(function() {
                   var code_html=<?php echo json_encode($cours); ?>;
                    $('#Affichage_Cours').DataTable({
                        data:code_html,
                        columns:
                        [
                           {'data':'idcour',
                            'searchable':false,
                            'sortable':false,
                            'render':function(idcour){return "<button data-toggle='modal' data-target='#modal_modifier' class='btn btn-info btn_modifier' value='"+idcour+"'><i class='fa fa-pencil-square-o'></i></button>"+"<button class='btn btn-danger  btn_supprimer' value='"+idcour+"'><i class='fa fa-times'></i></button>";}},
                          {'data':'idcour'},
                          {'data':'titrecour'},
                          {'data':'contenucour'},
                          {'data':'liencour','render':function(liencour){if(liencour=='pas de lien')return '----';return "<a href='fichiers/cours/"+liencour+"' target='_blank' alt='"+liencour+"'><i class='fa fa-file-o fa-2x'  aria-hidden='true'></i></a>";}},
                          {'data':'datecour'},
                          {'data':'lienimage','render':function(lienimage){return "<img class='img img-responsive' width='50%' src='images/cours/"+lienimage+"'/>";}},
                          {'data':'libellematiere'},
                          {'data':'nomutilisateur'}
                        ]
                        ,"autoFill":true,
                     "pagingType": "full_numbers",
                     "language": {
                                   "paginate": {
                                      "previous": "Prec",
                                      "first" : "début",
                                      "next": "suiv",
                                      "last":"fin"
                                    },
                        "lengthMenu": "Affichage _MENU_ lignes par page",
                        "zeroRecords": "Aucun Résultat  - ",
                        "info": "Résultat :  page _PAGE_ sur  _PAGES_ pages ",
                        "infoEmpty": "Aucun Résultat",
                        "infoFiltered": "(Filtré de _MAX_ Lignes)"
                    }
                    });
                    //Modifier
                    
                    $('.btn_modifier').click(function() {
                        var data=<?php echo json_encode($cours);?>;

                          var id=$(this).val();
                        $.each(data, function(i, item) {
                            if(item.idcour.toString()===id)
                            {
                              //La Copie du formulaire d'ajout
                              $('#modal_modifier_body').html('<form  id="form_modifier" method="post">'+$('#form').html()+"</form>");
                              $("#modal_modifier_body #form_modifier");
                                //Changer L'id & la valeur du button
                               $("#form_modifier #btn_ajouter").html("modifier").attr("id","btn_modifier").attr("value",id).attr("onclick","modifier_cours($('#form_modifier #btn_modifier'));$('#gestion').fadeOut(2000);professeur_gestion('cour');return false;");
                                
                                $("#form_modifier *[name='idmatiere']").prev().prepend("<input type='hidden' name='id' value='"+item.idcour+"'/>");
                                
                                //Remplissage du formulaire avec les valeurs de l'element
                                $("#form_modifier input[name='titre']").val(item.titrecour);
                                $("#form_modifier textarea[name='contenu']").text(item.contenucour);
                                
                                //Selectionner La Matiere Du Cours
                                
                                $("#form_modifier select[name='idmatiere'] option").each(function() {
                                     

                                      if($(this).text()==item.libellematiere)
                                      {
                                        $(this).attr("selected","selected");
                                      }
                                });

                            }
                        });
                       
                    });
                    //SUPPRIMER
                    
                      $(document).ready(function(){
                        $('.btn_supprimer').click(function() {
                        //S'il clique sur yes
                        if(confirm("Voulez vous vraiment Supprimé Ce Cours ? "))
                        {
                          
                          supprimer_cours($(this));
                          professeur_gestion("cour");
                        }
                      })
                    });

              });

                 
            

</script>
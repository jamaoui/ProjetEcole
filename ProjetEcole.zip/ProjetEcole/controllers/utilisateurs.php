<?php 
require_once($_SERVER['DOCUMENT_ROOT']."/ProjetEcole/models/utilisateurs.php");
class Cutilisateurs extends utilisateurs
{

	public static function tout_utilisateurs()
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];

		//VAR POUR COMPTER LE NOMBRE DE LIGNES POUR LE RESULTAT
		$nb=0;

		//VAR POUR ENVOYER LE RESULTAT
		$resultat=[];		

			$req=$CNX->prepare("SELECT utilisateurs.*,images.lien as 'lienimage'  FROM utilisateurs,images WHERE utilisateurs.idimage=images.id ORDER BY utilisateurs.id DESC");
		
			$req->execute();

			//Nombres de lignes 
		
		 $nb=$req->rowcount();

		 while($data=$req->fetch(PDO::FETCH_ASSOC))
			$resultat[]=$data;
		$resultat[0]['nombreutilisateurs']=$nb;
		return $resultat;

	}
	public static function connexion($login,$password)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];

		//SECURISER LES DONNEES AVEC LA FONCTION DEJA CREE
		
		$args=(Cutilisateurs::securite(func_get_args()));

		$i=0;
		
		//Recuperation des donnees securisee
		
		foreach (get_defined_vars() as $name=>$value)if($i<func_num_args())$$name=$args[$i++];else break;

		//LE  CRYPTAGE DU MOT DE PASSE
		
		$password=sha1($password);

		$req=$CNX->prepare("SELECT utilisateurs.*,images.lien,images.description FROM utilisateurs inner join images on utilisateurs.idimage=images.id WHERE login=:login AND password=:password");
		
		$req->execute(array('login'=>$login,'password'=>$password));
		
		//Nombres de lignes 
		
		 $nb=$req->rowcount();

		//TEST DE CONNEXION ...
		if($nb>0)
		{
			$data=$req->fetch(PDO::FETCH_ASSOC);
			$_SESSION['UTILISATEUR']=$data;
			@header("location:index.php");

		}
		else
		{
			?>
				<div class="panel panel-danger">
			    <div class="panel-heading">
			        <h3 class="panel-title">Erreur D'authentification</h3>
			    </div>
			    <div class="panel-body">
			       LOGIN/PASSWORD/TYPE SONT INCORRECTE !
			    	<a href="#" data-toggle="modal" data-target="#btnlogin" style="border-right: 1px solid #DADADA;border-left: 1px solid #DADADA;margin-right: 10px">Réssayer</a>
			    </div>

			</div>

			<?php
		}
		
	}
	
	//FONCTION DE VERIFICATION SI L'UTILISATEUR EST CONNECTE
	public static function is_connected($type='')
	{ if($type=='')
		return (isset($_SESSION['UTILISATEUR']));
	  else
	  	return (isset($_SESSION['UTILISATEUR']) && $_SESSION['UTILISATEUR']['type']==$type); 
	}


	//FONCTION DE DECONNEXION 
	public static function deconnexion()
	{
		session_unset($_SESSION);
		session_destroy();
		header("location:index.php");
	}

	//FONCTION POUR AJOUTER UN UTILISATEUR
	public static function ajouter_utilisateur($utilisateur)
	{
		
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		
		 //ID ET AUTOINCREMENT JE VAIS Pas Le Prendre
			
		//Recuperation des donnees

		//LE  CRYPTAGE DU MOT DE PASSE
		$password=sha1($utilisateur->getPassword());
		
		 $nom=$utilisateur->getNom();
		 $prenom=$utilisateur->getPrenom();
		 $login=$utilisateur->getLogin();
		 $type=$utilisateur->getType();
		 $idimage=$utilisateur->getIdImage();
		$req=$CNX->prepare("INSERT INTO utilisateurs VALUES(NULL,:nom,:prenom,:login,:password,:type,now(),:idimage)");

		$req->execute(
						array
							(
								'nom'=>$nom,
								'prenom'=>$prenom,
								'login'=>$login,
								'password'=>$password,
								'type'=>$type,
								'idimage'=>$idimage
							)
					 );
		
		
	}

		//FONCTION POUR MODIFIER UN UTILISATEUR
	public static function modifier_utilisateur($utilisateur)
	{
		
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		

		//LE  CRYPTAGE DU MOT DE PASSE
		
		$password=sha1($utilisateur->getPassword());
		 
		//Recuperation des donnees

		 $id=$utilisateur->getId();
		 $nom=$utilisateur->getNom();
		 $prenom=$utilisateur->getPrenom();
		 $login=$utilisateur->getLogin();
		 $type=$utilisateur->getType();
		 $idimage=$utilisateur->getIdImage();
		

		$reqid='';
		if($idimage!='')
			$reqid=" idimage='$idimage' ,";

		$req=$CNX->prepare("UPDATE utilisateurs SET nom=:nom,
													prenom=:prenom,
													login=:login,
													password=:password,
													$reqid
													type=:type

											WHERE id=:id
							");

		$req->execute(
						array
							(
								'id'=>$id,
								'nom'=>$nom,
								'prenom'=>$prenom,
								'login'=>$login,
								'password'=>$password,
								'type'=>$type
							)
					 );
		
		 //Verifier Si L'utilisateur veut modifier lui même ...
		 if($id==$_SESSION['UTILISATEUR']['id'])
		 {
		 	//Ecrasement des anciens valeurs de l'admin
		 	
		 	$resultat=$CNX->query("SELECT utilisateurs.*,images.lien,images.description FROM utilisateurs inner join images on utilisateurs.idimage=images.id WHERE utilisateurs.id='$id'");
			$_SESSION['UTILISATEUR']=$resultat->fetch(PDO::FETCH_ASSOC);

		 }	
	}
		public static function supprimer_utilisateur($utilisateur)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		$id=$utilisateur->getId();
		
		try{
		$req=$CNX->prepare("DELETE FROM utilisateurs WHERE id=:id");
			$req->execute(array('id'=>$id));
		}catch(Exception $e){die($e->getMessage());}
	}

} 
?>

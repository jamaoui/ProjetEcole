<?php
require_once ("../config/init.php");
require_once (server."config/connexion.php");
require_once(server."controllers/utilisateurs.php");
require_once(server."controllers/annonces.php");
require_once(server."controllers/matieres.php");


  $matieres=(Cmatieres::tout_matieres());
?>
            <div id="ajouter" class="tab-pane fade in active">
                    <h3>Ajouter Une Matiere</h3>
                   <form id="form" class="col-md-10" method="POST" onsubmit="ajouter_matiere(this);admin_gestion('matiere');return false;">
                          <fieldset class="form-group">

                            <label for="libelle">Libelle de la matiere : </label>
                        <input class="form-control" autofocus  type="text" name="libelle" id="libelle">
                            <hr>
                <button class="btn-block btn-lg btn btn-primary" id="btn_ajouter" type="submit">Ajouter</button>
                          <button class="btn-block btn-lg btn btn-warning" id="btn_reset" type="reset">Vider Les Champs</button>
                          </fieldset>
                  </form>
                    <!-------------------------------->
       <?php
        //s'il ne trouve aucune ressource
       
      if(count($matieres[0])<=1) die();?>
  
<!--DATATABLE!-->
             <table id="Affichage_Matieres"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="90%">
                <thead>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;Matiere</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th><i class="fa fa-pencil-square-o"></i><i class="fa fa-times"></i></th>
                 <th ><i class="fa fa-barcode " ></i>&nbsp;Code</th>
                <th><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;Matiere</th>
            </tr>
        </tfoot>
    </table>

    <script type="text/javascript">

         $(document).ready(function() {
                   var code_html=<?php echo json_encode($matieres); ?>;
                    $('#Affichage_Matieres').DataTable({
                        data:code_html,
                        columns:
                        [
                           {'data':'id',
                            'searchable':false,
                            'sortable':false,
                            'render':function(id){return "<button data-toggle='modal' data-target='#modal_modifier' class='btn btn-info btn_modifier' value='"+id+"'><i class='fa fa-pencil-square-o'></i></button>"+"<button class='btn btn-danger  btn_supprimer' value='"+id+"'><i class='fa fa-times'></i></button>";}},
                          {'data':'id'},
                          {'data':'libelle'}
                        ]
                        ,"autoFill":true,
                     "pagingType": "full_numbers",
                     "language": {
                                   "paginate": {
                                      "previous": "Prec",
                                      "first" : "début",
                                      "next": "suiv",
                                      "last":"fin"
                                    },
                        "lengthMenu": "Affichage _MENU_ lignes par page",
                        "zeroRecords": "Aucun Résultat  - ",
                        "info": "Résultat :  page _PAGE_ sur  _PAGES_ pages ",
                        "infoEmpty": "Aucun Résultat",
                        "infoFiltered": "(Filtré de _MAX_ Lignes)"
                    }
                    });
                    //Modifier
                    
                    $('.btn_modifier').click(function() {
                        var data=<?php echo json_encode($matieres);?>;

                          var id=$(this).val();
                        $.each(data, function(i, item) {
                            if(item.id.toString()===id)
                            {

                              //La Copie du formulaire d'ajout
                              $('#modal_modifier_body').html('<form  id="form_modifier" method="post">'+$('#form').html()+"</form>");
                              $("#modal_modifier_body #form_modifier");
                                //Changer L'id & la valeur du button
                               $("#form_modifier #btn_ajouter").html("modifier").attr("id","btn_modifier").attr("value",id).attr("onclick","modifier_matiere($('#form_modifier #btn_modifier'));$('#gestion').fadeOut(2000);admin_gestion('matiere');return false;");
                                $("#form_modifier *[name='libelle']").prev().prepend("<input type='hidden' name='id' value='"+item.id+"'/>");
                                //Remplissage du formulaire avec les valeurs de l'element
                                $("#form_modifier input[name='libelle']").val(item.libelle);
                               
                            }
                        });
                       
                    });
                    //SUPPRIMER
                    
                      $(document).ready(function(){
                        $('.btn_supprimer').click(function() {
                        //S'il clique sur yes
                        if(confirm("Voulez vous vraiment Supprimé cette Matiere ? "))
                        {
                          
                          supprimer_matiere($(this));
                          admin_gestion("matiere");
                        }
                      })
                    });

              });

                 
            

</script>
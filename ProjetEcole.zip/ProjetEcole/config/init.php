<?php
    define("server",$_SERVER['DOCUMENT_ROOT']."/ProjetEcole/");
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Espace Professeur</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/responsive.bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="icon" 	   type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
  </head>
<body>
<?php require_once("config/connexion.php"); ?>

<!--TEST DE CONNEXION DU DIRECTEUR-->

<?php if(!Cutilisateurs::is_connected('professeur'))header('location:index.php'); ?>



<nav class="navbar navbar-fixed-top" style='background-color:royalblue;' role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          </button>
          <a class="navbar-brand" style="color:white" href="#">Espace Professeur <i class="fa fa-tachometer"></i></a>
        </div>
        <div class="navbar-collapse collapse">
          <ul  class="nav navbar-nav navbar-right">
            <li><a href="index.php">Espace Public</a></li>
            <li><a href="deconnexion.php"><i class="fa fa-power-off"></i> </a></li>
          </ul>
        </div>
      </div>
</nav>
<div class="container-fluid " style="min-height:250vh">
      
      <div class="row row-offcanvas  row-offcanvas-left">
         <div class="col-sm-3 col-md-2 sidebar-offcanvas" id="sidebar" role="navigation" >
           
            <!--MENU ------------------------------------------------------>
            <ul class="nav nav-sidebar">
            <li><br><br><br><img data-toggle="tooltip" data-placement="bottom" title="Image de <?php echo $_SESSION['UTILISATEUR']['nom'].' '.$_SESSION['UTILISATEUR']['description']; ?>" src="images/utilisateurs/<?php echo $_SESSION['UTILISATEUR']['lien']; ?>" class="img-thumbnail"></li>
              <li><br><br></li>
              <li><button type="button" id="annonce" onclick="admin_gestion('annonce');" class="btn btn-md btn-info "> <i class="fa fa-newspaper-o"></i> Gestion Annonces &nbsp;&nbsp;</button></li>
              <li><br></li>
              <li><button type="button" id="cour"onclick="professeur_gestion('cour');" class="btn  btn-md btn-info "> <i class="fa fa-users"></i> Gestion Cours &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button></li>
              <li><br></li>
   
            </ul>


            <!---------------------------------------------------->

          
        </div><!--/span-->
        
        <div  class="col-sm-9 col-md-10 main">
          
      <h1 class="page-header"></h1>

          
          <div class="row placeholders">
            <div class="placeholder ">
                <div id="gestion" class="container col-md-12" >


              </div>
            </div>
          </div>
  
      </div><!--/row-->
  </div>
</div><!--/.container-->


<?php include("include/footer.php"); ?>
    <script src="js/ajax/annonces.js"></script>
    <script src="js/ajax/admin.js"></script>
    <!--APPELL A LA FONCTION POUR APPORTER LES INFOS-->

    <script type="text/javascript">
        $(document).ready(function() {
            admin_gestion("annonce");
        });
    </script>

</body>
</html>
<!DOCTYPE html>
<html>
  <head>
    <title>Bienvenue {Lycee Ibn Sina}</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="icon" type="icon/ico" href="favicon.ico">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    
  </head>
<body>

<?php include("include/nav.php"); ?>
<!-- ============================= site section1 ============================= -->
<div class="section1" style="background: url('images/home-bg.jpg');background-size: 100% 120%;background-repeat: no-repeat;">
</div>

<!-- ============================= site section 2 ============================= -->

<div class="for-section2">
<div class="section2" align="center">
	<p align="center">
	<div class="section2-div">
		<img src="images/books.png" />
		<h3>Espace Etudiant</h3>
		des cours  gratuits  pour vous en  (mathématiques,sciences,informatique...) 
		<br /><br /><br />
		<a href="espaceetudiants.php" class="browse-s" data-toggle="tooltip" data-placement="bottom" title="cliquer pour voir l'espace etudiant">Voir cette page</a>
    </div>
    <div class="section2-div">
		<img src="images/j-us.png" />
		<h3>9rayti</h3>
		Rejoignez-nous si vous souhaitez telecharger des cours , et nous serons très heureux si vous voyez  notre Application en cliquant sur le button <strong>9rayti</strong>.
       <br /><br />
		</div>
	<div class="section2-div">
		<img src="images/o-s-p.png" />
		<h3>Actualités</h3>
            Nous Partageons avec vous nos avis , nos future projets etc ... 
		<br /><br /><br /><br />
		<a href="annonces.php" class="browse-s" data-toggle="tooltip" data-placement="bottom" title="Nos Annonces ...">Voir Plus</a>
        </div>
</div></p>
</div>
<!-- ============================= site section3 ============================= -->
	<div class="section3" align="center">
		<h3 class="sec3-txt">3 etapes pour devenir un excellent élève</h3>
    <p style="margin:3%">Vous voulez devenir un bon élève ? Ce n'est pas si difficile que cela. Il faut bien sûr de la volonté et du courage, mais vous en avez n'est-ce pas ? Pour devenir un bon élève, commencez par lire cet article !</p>
		<div style="display: inline-block">
		<section class="steps"><p style="margin: 10px">
	<span class="step">1</span>
<h5>Comme tous les étudiants exceptionnellement bons, vous devez être attentif !</h5>
Quand un professeur donne un cours, prenez des notes et si vous ne comprenez pas quelque chose, levez la main et posez des questions. Plus vous posez de questions, plus vous deviendrez intelligent, croyez-le ou non. En faisant passer des petits mots et en parlant à vos amis, vous n'apprendrez rien, donc faites attention !
</p><br />
<p style="margin: 10px">
	<span class="step">2</span>
	<h5>Organisez-vous.</h5>
  <p style="margin:3%">Rester organisé à l'école est très important. Si vous êtes organisé, vous avez une longueur d’avance pour réussir. Gardez un classeur pour chaque matière, et oui, il faut que vous mettiez vos feuilles de mathématiques dans votre classeur de maths, vos feuilles de littérature dans votre dossier de littérature, vos feuilles de sciences dans votre classeur de sciences, et ainsi de suite. Une autre bonne idée est d’utiliser un code couleur ou d’étiqueter vos dossiers.</p>
	</p><br />
<p style="margin: 10px">
	<span class="step">3</span>
	<h5>Prenez le temps pour écrire quelques problèmes à résoudre, sinon, vous pouvez demander à quelqu'un de les écrire pour vous.</h5>
  <p style="margin:3%">Rappelez-vous que ça ne fait pas de mal de relire ce que vous avez appris.</p>
	</p>
		</section>
		<section style="
    width: 250px;
    height: 200px;
    background: url('images/pc2.png');
    background-size: cover;
    float: right;
		"></section>
	</div></div>
<!-- ============================= site section teem ============================= -->
<div align="center">
	<h1 style="text-align: center;">Notre équipe de développement</h1><hr style="width: 200px;"/>
	<div style="padding: 20px;text-align: center;
    display: inline-block;
    width: auto;
    max-width: 300px;
    min-width: 172px;
    text-align: center;
    padding: 15px;
    transition: all 0.4s;
">
	<p align="center" style="background: url('images/jamaoui.jpg') no-repeat;background-size: cover;width: 200px;height: 200px;    display: -webkit-inline-box;border-radius: 100px 100px 100px 100px;"></p>
    <h4 align="center">
    	Jamaoui Mouad
    </h4>
    <p align="center">
    	Développeur Web 
        & Designer 
    </p>
</div>
</div>

<?php    include("include/footer.php"); ?>

</body>
</html>

<?php
    require_once ("../config/init.php");
    require_once(server."config/connexion.php");
    require_once(server."controllers/cours.php");
    //AFFICHER TOUT LES COURS ET TOUS LES EXERCICES
    if(isset($_POST['afficher_cours_exercices']))
    {
    	
    	$cours=(Ccours::tout_cours());
    	$datalist='';

    	foreach ($cours as $key => $value)
    	{
    		$datalist.="<option value='".htmlentities ($value['titrecour'])."'>Cours</option>";			    
    		//pour annuler la repetition des noms
    		if(strpos($datalist,$value['nomutilisateur'])<=0)
			$datalist.="<option value='".htmlentities ($value['nomutilisateur'])."'>nom d'utilisateur</option>";
    
    	 		?>
		    	 <li id="li" >
		              <a onclick="voir_cour(<?php echo $value['idcour']; ?>);return false;" title="<?php echo "Telecharger Le Cours ".$value['titrecour']; ?>" class='normal' href='#' style="background: url('images/cours/<?php echo $value['lienimage']; ?>') no-repeat;background-size:cover;"></a>
		              <div class='info'>
		                <h3><?php echo $value['titrecour']; ?></h3>
		                <h6 style="bottom:0;position:absolute;right:3%;"><strong style='color:aliceblue'><?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?></strong></h6>
		                <p><br><?php echo substr($value['contenucour'],0,102)." ..."; ?><strong>Voir Plus</strong></p>
		              </div>
		          </li>

    	 		<?php
    	 }
    	 ?>
    	 	<script type="text/javascript">
    	  $(document).ready(function() {
    	  	$("#datalist").empty();
    	  	$("#datalist").append("<?php echo ($datalist); ?>");

    	  });
    	  </script>
    	 <?php	
    }
    else if(isset($_POST['afficher_cour'])) 
    {
    	$id=$_POST['afficher_cour'];

    	if(!empty($id))
    	{
    		$value=(Ccours::tout_cours($id));
    		$value=$value[0];
    	 		?>
    	 			<div class="container" id="cour_profile">
					    <div class="row">
					        <div class="col-xs-12 col-sm-6 col-md-10">
					            <div class="well well-sm">
					                <div class="row">
					                    <div class="col-sm-6 col-md-4">
					                        <img src="images/cours/<?php echo $value['lienimage']; ?>" alt="<?php echo $value['descriptionimage']; ?>" class="img-rounded img-responsive" />
					                    </div>
					                    <div class="col-sm-6 col-md-8">
					                    <h3><?php echo $value['titrecour']; ?></h3>
					                        <h5>
					                        <i class="fa fa-university"></i> &nbsp;&nbsp;
					                        <?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?>
					                        </h5>
					                        
					                        <p>
					                            <i class="fa fa-calendar"> &nbsp;&nbsp;</i><?php echo $value['datecour']; ?>
					                            <br />
					                            <i class="fa fa-hashtag"></i>&nbsp;&nbsp;Cours <?php echo $value['libellematiere']; ?> </p>
					                        <p><br><?php echo ($value['contenucour']); ?></p>

					                        <div class="btn-group">
					                        		<!--S 'il y a aucun lien -->
					                        		<?php if ($value['liencour']=='pas de lien'): ?>
					                        			<a disabled onclick="return false;" class="btn btn-lg btn-primary" href="#"><i class="fa  fa-frown-o fa-1x"></i> Fichier Indisponible</a>
					                        		<?php endif ?>

					                        		<!--S 'il y a un lien-->
					                        		
					                        		<?php if ($value['liencour']!='pas de lien'): ?>
					                        			<a  class="btn btn-lg btn-primary"  href="fichiers/cours/<?php echo $value['liencour']; ?>"><i class="fa fa-floppy-o fa-1x"></i> <?php echo $value['titrecour']; ?></a>
					                        		<?php endif ?>
					                           <a  class="btn btn-lg btn-success" onclick="voir_cours('');return false;"  href="return false;"><i class="fa fa-times fa-1x"></i> Retour</a>
					                        </div>
					                    </div>
					                </div>
					            </div>
					        </div>
					    </div>
					</div>

		    	        
		                
    	 		<?php
    	}
    }
    else if(isset($_POST['afficher_cours_recherche']))
    {
    	$recherche=$_POST['afficher_cours_recherche'];

    	if(!empty($recherche))
    	{

    		    	$cours=(Ccours::tout_cours('',$recherche));
			    	foreach ($cours as $key => $value)
			    	{
			    	 		?>
					    	 <li id="li" >
					              <a onclick="voir_cour(<?php echo $value['idcour']; ?>);return false;" title="<?php echo "Telecharger Le Cours ".$value['titrecour']; ?>" class='normal' href='#' style="background: url('images/cours/<?php echo $value['lienimage']; ?>') no-repeat;background-size:cover;"></a>
					              <div class='info'>
					                <h3><?php echo $value['titrecour']; ?></h3>
					                <h6 style="bottom:0;position:absolute;right:3%;"><strong style="color:white;"><?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?></strong></h6>
					                <p><br><?php echo substr($value['contenucour'],0,102)." ..."; ?><strong>Voir Plus</strong></p>
					              </div>
					          </li>

			    	 		<?php
			    	 }	
    	}
    } 

    
?>
<?php require_once("config/connexion.php"); ?>
<nav class="navbar navbar-inverse">
   <img align="right" width="10%" style="box-shadow:-2px -3px 5px black;border-radius:100%;margin-top:1%;right:25%;position:absolute" src="images/Logo_Lycee.png">
   <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <i style="color:white" class="fa fa-bars" aria-hidden="true"></i>
      </button>
      <a class="navbar-brand"  href="index.php">Lycée IbnSina</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active">
          <a href="index.php" id="index" data-toggle="tooltip" data-placement="bottom" title="" id="focus" data-original-title="notre page d'accueil">Accueil</a>
        </li>
        <li><a href="espaceetudiants.php" id="espaceetudiants" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="des cours et des exercices gratuits...">Espace Etudiant</a></li>
        <li><a href="annonces.php" id="annonces" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="les derniers annonces et informations de notre lycée">Annonces</a></li> 
        <li class="active">
          <a href="contact.php" id="contact" data-toggle="tooltip" data-placement="bottom" title=""  data-original-title="Vous voulez vous contacter? cliquez ici !">Contact</a>
        </li>
      <!--CONNECTE ADMIN!-->
      <?php if (Cutilisateurs::is_connected('directeur')): ?>
           <li class="active">
          <a href="admin.php" style="background-color:lightblue;color:white" id="contact" data-toggle="tooltip" data-placement="bottom" title=""  data-original-title="Espace Administrateur"><i class="fa fa-user" aria-hidden="true"></i></a>
        </li>    
      <?php endif ?>

          <!--CONNECTE Professeur!-->
          <?php if (Cutilisateurs::is_connected('professeur')): ?>
              <li class="active">
                  <a href="professeur.php" style="background-color:lightblue;color:white" id="contact" data-toggle="tooltip" data-placement="bottom" title=""  data-original-title="Espace Administrateur"><i class="fa fa-user" aria-hidden="true"></i></a>
              </li>
          <?php endif ?>
          <!--CONNECTE Etudiant!-->
          <?php if (Cutilisateurs::is_connected('etudiant')): ?>
              <li class="active">
                  <a href="etudiant.php" style="background-color:lightblue;color:white" id="contact" data-toggle="tooltip" data-placement="bottom" title=""  data-original-title="Espace Administrateur"><i class="fa fa-user" aria-hidden="true"></i></a>
              </li>
          <?php endif ?>

      </ul>
      <ul class="nav navbar-nav navbar-right">
      <!--S'IL N'EST PAS CONNECTE!-->
      <?php if (!IS_CONNECTED): ?>
           <li data-toggle="tooltip" data-placement="bottom" title="" data-original-title="connexion a votre compte"><a href="#" data-toggle="modal" data-target="#btnlogin" style="border-right: 1px solid #DADADA;border-left: 1px solid #DADADA;margin-right: 10px">Connexion</a></li>
           <li data-toggle="tooltip" data-placement="bottom" title="" data-original-title="des informations sur les développeurs"><a data-toggle="modal" data-target="#btndesigner" style="line-height:40px;width: 50px;height: 50px;background: url('images/infos.png') no-repeat;background-size: cover;"  href="#" ></a></li>
      <?php endif ?>


      <!--S'IL EST  CONNECTE PROF!-->
      <?php if (IS_CONNECTED): ?>
           <li  data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Deconnexion de votre compte"><a href="deconnexion.php" style="padding-bottom:10px;float:right;width:50px"><img src="images/deconnexion.png"  width="100%"></a></li>
           <li data-toggle="tooltip" data-placement="bottom" title="" data-original-title="Votre Compte"><a data-toggle="modal" data-target="#btndesigner" style="line-height:40px;width: 50px;height: 50px;background: url('images/utilisateurs/<?php echo $_SESSION['UTILISATEUR']['lien']; ?>') no-repeat;background-size: cover;" href="#"></a></li>
      <?php endif ?>
           </ul>
    </div>
  </div></nav>

  <!-- ============================= login dialog ============================= -->
  <div id="btnlogin" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background: royalblue;color: white;">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Connexion</h4>
        </div>
        <div class="modal-body">
          <p>
          </p><form  role="form" method="POST">
          <div class="form-group">
           <label>Login<label style="color: blue">&nbsp;*</label></label>
           <input required value='<?php echo isset($_POST['login'])?$_POST['login']:''; ?>' autofocus type="text" name="login" class="form-control" id="email" placeholder="Entrer votre login">
         </div>
         <div class="form-group">
           <label>Mot de Passe<label style="color: blue">&nbsp;*</label></label>
           <input required  type="password" name="password" class="form-control" id="pwd" placeholder="Entrer your mot de passe">
         </div>
         <div class="checkbox">
          <label><input name="se_souvenir_de_moi" type="checkbox"> se souvenir de moi</label>
        </div>
        <button type="submit" name="connexion" class="btn-flat-blue">Connexion</button>
      </form>
      <p></p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-flat-blue" data-dismiss="modal">Fermer</button>
    </div>
  </div>

</div>
</div>

<!-- ============================= DEVELOPPEUUUUUUUUUUUUUUUURS ============================= -->
<?php if (!IS_CONNECTED): ?>
  <div id="btndesigner" class="modal fade" role="dialog">

  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background: rgb(21, 185, 255);color: #ffffff;">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">A propos des developpeurs</h4>
      </div>
      <div class="modal-body">
        <div align="center">
        <!--INFORMATIONS SOCIAL JAMAOUI!-->
        <table width="100%" >
          <tr>
          <td></td>
              <td width="20%" align="center"> <a  data-toggle="tooltip" title="Compte Youtube" class="youtube social" href="https://www.youtube.com/channel/UCUNnFmj-VIpbERooz_Znzfg"></a></td>
              <td width="20%" align="center"> <a  data-toggle="tooltip" title="Compte Twitter" class="twitter2 social" href="https://twitter.com/jamaouimouad"></a></td>
             <td width="20%" align="center"> <a   data-toggle="tooltip" title="Compte LinkedIn" class="linkedin social" href="https://www.linkedin.com/in/mouad-jamaoui-3940a0ba"></a></td>
              <td></td>
          </tr>
          <tr>
             <td rowspan="2" align="center" width="20%" > <a data-toggle="tooltip" title="Compte Facebook" class="facebook2 social" href="https://www.facebook.com/JamaouiMouad"></a></td>
              <td></td><td></td><td></td>
           <td width="20%" align="center"><a data-toggle="tooltip" title="voulez vous Envoyer un message  ? " href="mailto:jamaoui.mouad@hotmail.com" style="text-decoration:none;font-size:4rem;">&#9993;</a></td>
         
          </tr>
        </table>

         <div style="padding: 20px;text-align: center;
          display: inline-block;
          width: auto;
          max-width: 300px;
          min-width: 172px;
          text-align: center;
          padding: 15px;
          transition: all 0.4s;">
          <p align="center" style="background: url('images/jamaoui.jpg') no-repeat;background-size: cover;width: 200px;height: 200px;    display: -webkit-inline-box;border-radius: 100px 100px 100px 100px;"></p>
          <h4 align="center">
            Jamaoui Mouad ☺
          </h4>
          <p align="center">
            marocain.<br>
            Je travaille en tant que développeur Web et programmeur et chercheur de sécurité, je construit beaucoup de projets
            html-css-js-jq-php-bs, et je les  télécharge sur Internet gratuitement pour tous les autres développeurs
          </p>
        </div>
      </div>
    </div>

    <hr style="border:dashed 1px royalblue;">

  <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
  </div>
</div>
</div>
</div>
<?php endif ?>
<?php if (IS_CONNECTED): ?>
  <div id="btndesigner" class="modal fade modaldialogmodifier"  role="dialog">

  <div class="modal-dialog" >
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background: rgb(21, 185, 255);color: #ffffff;">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Votre Compte Mr <?php echo $_SESSION['UTILISATEUR']['nom']." ".$_SESSION['UTILISATEUR']['prenom']; ?></h4>
      </div>
      <div class="modal-body">
        <div align="center">
         <div style="padding: 20px;text-align: center;
          display: inline-block;
          width: auto;
          max-width: 300px;
          min-width: 172px;
          text-align: center;
          padding: 15px;
          transition: all 0.4s;">
          <p align="center" width="100px">
            <img width="100%" id='apercu_image'  style="border-radius:100%;" src="images/utilisateurs/<?php echo $_SESSION['UTILISATEUR']['lien']; ?>">
          </p>
          
          
          <?php if ($_SESSION['UTILISATEUR']['type']=="directeur"): ?>
            <h4 align="center"><span class="label label-pill label-primary">Directeur</span></h4>
          <?php endif ?>
          <?php if ($_SESSION['UTILISATEUR']['type']=="professeur"): ?>
             <h4><span class="label label-pill label-default">Professeur</span></h4>
          <?php endif ?>
             
             <form id="modifier_utilisateur" method="POST" role="form">
               <legend>Modifier Vos Informations </legend>
             
               <div class="form-group">
                <input type="hidden" name="id"  value="<?php echo $_SESSION['UTILISATEUR']['id']; ?>" class="form-control" id="" placeholder="Numero du compte">
                <input type="hidden" name="type"  value="<?php echo $_SESSION['UTILISATEUR']['type']; ?>" class="form-control">
             
             <label for="nom">Votre Nom</label>
                 <input type="text"  value="<?php echo $_SESSION['UTILISATEUR']['nom']; ?>"
              class="form-control" name="nom" id="nom" placeholder="Votre Nom ">
              
               <label for="prenom">Votre Prénom</label>
                 <input type="text"  value="<?php echo $_SESSION['UTILISATEUR']['prenom']; ?>"
              class="form-control" name="prenom" id="prenom" placeholder="Votre Prenom ">
               
               <label for="login">Votre Login</label>
                 <input type="text"  value="<?php echo $_SESSION['UTILISATEUR']['login']; ?>"
              class="form-control" name="login" id="login" placeholder="Votre Login ">
               
               <label for="password">Votre Mot de passe</label>
                 <input type="password"  value="" class="form-control" name="password" id="password" placeholder="Votre Mot de passe ">
             
             <label class="file">Image
              <input type="file" onchange="readURL(this)"  value="" class="form-control" name="image" id="image" placeholder="Votre image ">
              <span class="file-custom"></span>
            </label>

               <button type="submit" name="modifier" onclick="modifier_utilisateur_utilisateur(this);" class="btn btn-primary btn-block btn-lg">Modifier 🔧</button>
            </div> </form>
         
        </div>
      </div>
    </div>
    <hr style="border:dashed 1px royalblue;">
    
  <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
  </div>
</div>
</div>
</div>
<?php endif ?>
<?php 
    if(isset($_POST['connexion']))
    {
        extract($_POST);
        if(!empty($login) && !empty($password))
        {
           Cutilisateurs::connexion($login,$password);
        }
        else
        {
           echo' <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <strong>Champ(s) non rempli(s)</strong> s\'il vous plait veuillez renseigner tout les champs  ...
            </div>';
        }

    }
   
?>
<script type="text/javascript">
function modifier_utilisateur_utilisateur(arg)
{
        $(arg).attr('disabled','disabled');
        $(arg).html('<i class="fa fa-spinner fa-spin fa-fw margin-bottom"></i>Modification En cours ...');
         var form=$(arg).parent().parent();
         var formData = new FormData(form[0]);
        //LANCER LA REQUETTE DE Modification
        
      $.ajax({
                type:'POST',
                url: 'views/admin.php?modifier_utilisateur',
                data:formData,
                cache:false,
                contentType: false,
                processData: false,
                success:function(data){ 
                //Cacher La Fenetre Modal
                $('.modaldialogmodifier').modal('hide');
                $(arg).removeAttr("disabled");
                $(arg).html('Modifier 🔧');
        
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
           
        });
      return false;
}

function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#apercu_image').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);

    }
}


</script>

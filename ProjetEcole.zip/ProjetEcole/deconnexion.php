<!DOCTYPE html>
<html>
  <head>
    <title>Deconnexion En cours ...</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="icon" type="icon/ico" href="favicon.ico">
    
  </head>
<body>
	<?php include("include/nav.php"); ?>
	<?php Cutilisateurs::deconnexion(); ?>
	<?php include("include/footer.php"); ?>

</body>

</html>
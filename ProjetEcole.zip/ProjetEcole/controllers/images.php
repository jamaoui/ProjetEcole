<?php 
	
require_once(server."models/images.php");
class CImages extends images
{
	public static function ajouter_image($image)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		//Recuperation des donnees
		
		 $id=$image->getId();
		 $lien=$image->getLien();

		 $description=$image->getDescription();

		 $chemin=$image->getChemin();

		 $valide = @getimagesize($lien["tmp_name"]);
	     //SI LA PHOTO EST VALIDE
	     if($valide !== false) 
	     {
	     	 
	     	 $photo=uniqid()."_".basename($lien["name"]);

			 if (move_uploaded_file($lien["tmp_name"],server.'images/'.$chemin.'/'.$photo)) {
		       
			 //PREPARATION DE LA REQUETE
			 
			 $req=$CNX->prepare("INSERT INTO images VALUES(NULL,:photo,:description,now())");
		 	 
		 	 $req->execute(array
		 	 					(
		 	 						'photo'=>$photo,
		 	 						'description'=>$description
		 	 					)
		 	 				);

		 	 return @$CNX->lastInsertId();
		     }
			    	
	    }
	
		 

	}
	public static function ajouter_image_absolute($description,$chemin,$tmp_name,$name)
	{
		//RECUPERATION DE LA CONNEXION PDO
		
		$CNX=$GLOBALS['cnx'];
		
		

		 $valide = @getimagesize($tmp_name);
	     //SI LA PHOTO EST VALIDE
	     if($valide !== false) 
	     {
	     	 
	     	 $photo=uniqid()."_".basename($name);

			 if (move_uploaded_file($tmp_name,server.'images/'.$chemin.'/'.$photo)) {
		       
			 //PREPARATION DE LA REQUETE
			 
			 $req=$CNX->prepare("INSERT INTO images VALUES(NULL,:photo,:description,now())");
		 	 
		 	 $req->execute(array
		 	 					(
		 	 						'photo'=>$photo,
		 	 						'description'=>$description
		 	 					)
		 	 				);

		 	 return @$CNX->lastInsertId();
		     }
			    	
	    }
	
		 

	}
}
?>

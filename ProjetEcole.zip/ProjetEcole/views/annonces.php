<?php
    require_once ("../config/init.php");
    require_once(server."config/connexion.php");
    require_once(server."controllers/annonces.php");
    require_once(server."controllers/utilisateurs.php");
    //AFFICHER TOUT LES Annonces
    if(isset($_POST['afficher_annonces']))
    {
    	
    	$annonces=(Cannonces::tout_annonces());
    	?>	<a class="list-group-item active" >Nos Annonces : <span class="badge"><?php echo ($annonces[0]['nombreannonces']); ?> Annonces en total </span></a>
			          
    	<?php
    	
    	$datalist=' ';

    	if(count($annonces[0])>1)
    	foreach ($annonces as $key => $value)
    	{
    			$datalist.="<option value='".(($value['titreannonce']))."'>Annonce</option>";			    
    			//pour annuler la repetition des noms
    			if(strpos($datalist,$value['nomutilisateur'])<=0)
			    $datalist.="<option value='".(($value['nomutilisateur']))."'>nom d\'utilisateur</option>";
    	 	?>
			          <div class="list-group-item  col-md-12 ">
				          <div class="col-md-12">
				          <?php if ($value['stickerannonce']=='true'): ?>
				          <strong class="pull-right" style="color:royalblue">
				          	<strong style="color:blue">Annonce Importante</strong>  
				          		<i class="fa fa-bookmark fa-3x"></i>
				        	</strong>
				          <?php endif ?>
				          <?php if ($value['stickerannonce']=='false'): ?>
				          	<strong class="pull-right" style="color:lightblue">
				          		<i class="fa fa-bookmark-o fa-3x"></i>
				          		<strong></strong>
			             </strong>
				          <?php endif ?>
						 </div>
		              <h3><?php echo $value['titreannonce']; ?></h3>
			          <div class="col-md-2">
			            <img  src="images/annonces/<?php echo $value['lienimage']; ?>" class="img-responsive ">
			          </div>
			          <div class="col-md-8">

			    			<?php echo substr($value['contenuannonce'],0,302)." ......"; ?>
			    		
			          </div>
			          <div class="col-md-1">
			             <span class="badge" style="background: royalblue;color:lightyellow">
					          <?php if ($value['nombreetoilesannonce']<=0): ?>
					          		Pas D'etoiles
					          <?php endif ?>
							<?php 
							//AFFICHAGE DES ETOILES DE L'ANNONCE
							$i=0; while ($i < $value['nombreetoilesannonce']): ?>
							<?php $i++; ?>
							<i class="fa fa-star"></i>
							<?php endwhile ?>		
						</span>
			          </div>
			          <div class="col-md-12">
			          	<h6 class="col-md-5 pull-left"><i style="color:royalblue" class="fa fa-user fa-2x"></i> <?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?></h6>
			          	<div class="col-md-5">
			          		<button class='btn btn-primary' onclick="voir_annonce(<?php echo $value['idannonce']; ?>);return false;" data-toggle="tooltip" data-placement="bottom" title="<?php echo "Telecharger L'annonce ".$value['titreannonce']; ?>"><i class="fa fa-chevron-circle-down"></i>&nbsp;&nbsp;voir plus</button> 
							  <?php if (Cutilisateurs::is_connected() && $_SESSION['UTILISATEUR']['id']===$value['idutilisateur']): ?>
							  	
							  <button class="btn dropdown-toggle btn-primary" data-toggle="dropdown">
							    <span class="caret"></span>
							  </button>
							  <ul class="dropdown-menu" style="padding:0" >
							   <li><button class='btn btn-primary btn-block btn_modifier' onclick="preparer_modification(this)" data-toggle='modal' data-target='#modal_modifier' value='<?php echo $value['idannonce']; ?>'><i class="fa fa-pencil-square-o fa-1x" aria-hidden="true"></i></button></li>
							   <li><button class='btn btn-danger  btn-block btn_supprimer' value='<?php echo $value['idannonce']; ?>'><i class="fa fa-times fa-1x" aria-hidden="true"></i></button></button></li>
							  </ul>
							  <?php endif ?>
							
			          	</div>	
			          	<p class="pull-right col-md-2"><i class="fa fa-calendar"></i>&nbsp;&nbsp;<?php echo $value['dateannonce']; ?></p>
			          </div>
			        </div>
    	 		<?php
    	 }
    	 else
    	 echo "<a class='list-group-item' style='min-height:60px;line-height:60px;text-align:center;' href='#' >Ooops , Pas d'annonces ...</a>";	
    	?>
    	<?php 
    		//TEST CONNECION DIRECTEUR
    	if (Cutilisateurs::is_connected('directeur')): ?>
    		
    	<?php endif ?>

    	<script type="text/javascript">
    	  $(document).ready(function() {
    	  	$("#datalist").empty();
    	  	var val="<?php echo ($datalist); ?>";
    	  	$("#datalist").append(val);

    	  });
    	  </script>
    	
    	<?php 
    }
    else if(isset($_POST['afficher_annonce'])) 
    {
    	$id=$_POST['afficher_annonce'];

    	if(!empty($id))
    	{
    		$value=(Cannonces::tout_annonces($id));
    		$value=$value[0];
    	 		?>
    	 			<div class="container" id="annonce_profile">
					    <div class="row">
					        <div class="col-xs-12 col-sm-6 col-md-10">
					            <div class="well well-sm">
					                <div class="row">
					                    <div class="col-sm-6 col-md-4">
					                        <img src="images/annonces/<?php echo $value['lienimage']; ?>" alt="<?php echo $value['descriptionimage']; ?>" class="img-rounded img-responsive" />
					                    </div>
					                    <div class="col-sm-6 col-md-8">
					                    <h3><?php echo $value['titreannonce']; ?></h3>
					                        <h5>
					                        <i class="fa fa-university"></i> &nbsp;&nbsp;
					                        <?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?>
					                        </h5>
					                        
					                        <p>
					                            <i class="fa fa-calendar"> &nbsp;&nbsp;</i><?php echo $value['dateannonce']; ?>
					                            <br />
					                            <i class="fa fa-hashtag"></i>&nbsp;&nbsp; Annonce  <?php //echo $value['libellematiere']; ?> </p>
					                        <p><br><?php echo ($value['contenuannonce']); ?></p>

					                        <div class="btn-group">
					                        		<!--S 'il y a aucun lien -->
					                        		<?php if ($value['lienannonce']=='pas de lien'): ?>
					                        			<a disabled onclick="return false;" class="btn btn-lg btn-primary" href="#"><i class="fa fa-edge fa-1x"></i> Pas de source </a>
					                        		<?php endif ?>

					                        		<!--S 'il y a un lien-->
					                        		
					                        		<?php if ($value['lienannonce']!='pas de lien'): ?>
					                        			<a target="_BLANK" class="btn btn-lg btn-primary"  href="<?php echo $value['lienannonce']; ?>"><i class="fa fa-edge fa-1x"></i> Source De L'annonce</a>
					                        		<?php endif ?>
					                           <a  class="btn btn-lg btn-success" onclick="voir_annonces('');return false;"  href="return false;"><i class="fa fa-arrow-left fa-1x"></i> Retour</a>
					                        </div>
					                    </div>
					                </div>
					            </div>
					        </div>
					    </div>
					</div>

		    	        
		                
    	 		<?php
    	}
    }
    else if(isset($_POST['afficher_annonces_recherche']))
    {
    	$recherche=$_POST['afficher_annonces_recherche'];
    	if(!empty($recherche))
    	{

    		    	$annonces=(Cannonces::tout_annonces('',$recherche));
			    	if(count($annonces[0])>1)
			    	{
			    		echo "<a class='list-group-item active'>Nos Annonces : <span class='badge'>".($annonces[0]['nombreannonces'])." Annonces en total </span></a>";
			    	
			
			    	foreach ($annonces as $key => $value)
			    	{
			    	 		?>
						<div class="list-group-item  col-md-12 ">
				          <div class="col-md-12">
				          <?php if ($value['stickerannonce']=='true'): ?>
				          <strong class="pull-right" style="color:royalblue">
				          	<strong style="color:blue">Annonce Importante</strong>  
				          		<i class="fa fa-bookmark fa-3x"></i>
				        	</strong>
				          <?php endif ?>
				          <?php if ($value['stickerannonce']=='false'): ?>
				          	<strong class="pull-right" style="color:lightblue">
				          		<i class="fa fa-bookmark-o fa-3x"></i>
				          		<strong></strong>
			             </strong>
				          <?php endif ?>
						 </div>
		              <h3><?php echo $value['titreannonce']; ?></h3>
			          <div class="col-md-2">
			            <img  src="images/annonces/<?php echo $value['lienimage']; ?>" class="img-responsive ">
			          </div>
			          <div class="col-md-8">

			    			<?php echo substr($value['contenuannonce'],0,302)." ......"; ?>
			    		
			          </div>
			          <div class="col-md-1">
			             <span class="badge" style="background: royalblue;color:lightyellow">
					          <?php if ($value['nombreetoilesannonce']<=0): ?>
					          		Pas D'etoiles
					          <?php endif ?>
							<?php 
							//AFFICHAGE DES ETOILES DE L'ANNONCE
							$i=0; while ($i < $value['nombreetoilesannonce']): ?>
							<?php $i++; ?>
							<i class="fa fa-star"></i>
							<?php endwhile ?>		
						</span>
			          </div>
			          <div class="col-md-12">
			          	<h6 class="col-md-5 pull-left"><i style="color:royalblue" class="fa fa-user fa-2x"></i><?php echo $value['nomutilisateur']." ".$value['prenomutilisateur']; ?></h6>
			          	<div class="col-md-5">
			          		<button class='btn btn-primary' onclick="voir_annonce(<?php echo $value['idannonce']; ?>);return false;" data-toggle="tooltip" data-placement="bottom" title="<?php echo "Telecharger L'annonce ".$value['titreannonce']; ?>"><i class="fa fa-chevron-circle-down"></i>&nbsp;&nbsp;voir plus</button> 
							  <?php if ($_SESSION['UTILISATEUR']['id']===$value['idutilisateur']): ?>	
							  <button class="btn dropdown-toggle btn-primary" data-toggle="dropdown">
							    <span class="caret"></span>
							  </button>
							  <ul class="dropdown-menu" style="padding:0" >
							   <li><button class='btn btn-primary btn-block btn_modifier' onclick="preparer_modification(this)" data-toggle='modal' data-target='#modal_modifier' value='<?php echo $value['idannonce']; ?>'><i class="fa fa-pencil-square-o fa-1x" aria-hidden="true"></i></button></li>
							   <li><button class='btn btn-danger  btn-block btn_supprimer' value='<?php echo $value['idannonce']; ?>'><i class="fa fa-times fa-1x" aria-hidden="true"></i></button></button></li>
							  </ul>
							  <?php endif ?>
							
			          	</div>		
			          	<p class="pull-right col-md-2"><i class="fa fa-calendar"></i>&nbsp;&nbsp;<?php echo $value['dateannonce']; ?></p>
			          </div>
			        </div>

			    	 		<?php
			    	 }	
			    }
			    else
			    {
			    	?>
			    		<a class="list-group-item active">Nos Annonces : <span class="badge"><?php echo ($annonces[0]['nombreannonces']); ?> Annonces en total </span></a>
			
			    		 <div class="alert alert-danger">
			    	<div class="panel-heading">Erreur 404</div>
					 <div class="panel-body">
					   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			                <strong>Pas de Résultat:</strong> &nbsp;Désolé Mais Nous n'avons trouvé aucun résultat ...
			       
					  </div>
  						
			                     </div>'
			    	<?php
			    }
    	}
    } 

    
?>
<script type="text/javascript">
	function preparer_modification(obj)
                        {
                       <?php echo "var data=".json_encode(@$annonces);?>;
                        
                          var id=$(obj).val();
                    $("#chargement_modification").remove();
                    $("#div_annonces *[value="+id+"]").parent().parent().parent().parent().prepend('<i id="chargement_modification" style=\'color:blue;float:right\' class="fa fa-cog  fa-5x fa-fw margin-bottom"></i>');
            			
                        $.each(data, function(i, item) {
                            if(item.idannonce.toString()===id)
                            {
                                //Remplissage du formulaire avec les valeurs de l'element
                                $("#form_modifier textarea[name='titre']").text(item.titreannonce);
                                $("#form_modifier textarea[name='contenu']").text(item.contenuannonce);
                                
                                if(item.lienannonce!='pas de lien')
                                $("#form_modifier *[name='lien']").val(item.lienannonce);
                                
                                $("#form_modifier *[name='nombreetoiles']").val(item.nombreetoilesannonce);
                                //Appell a la fonction pour animer les etoiles
                                nbretoiles(item.nombreetoilesannonce.toString());
                                //Ajouter L'apercu
                                $("#form_modifier p#image").html("<img  class='img img-responsive'src='images/annonces/"+item.lienimage+"'/>");
                                $("#form_modifier p#image").prepend("<input type='hidden' name='id' value='"+item.idannonce+"'/>");

                                //Les Radios 

                                if(item.stickerannonce==='true')
                                {
                                  $("#form_modifier *[name='sticker'][value='true']").attr('checked','true');
                                  $("#form_modifier *[name='sticker'][value='false']").attr('checked','false');
                                }


                            return ;
                            }
                        }); 
                }
                    $(document).ready(function() {
                    //SUPPRIMER
                    $('.btn_supprimer').click(function() {
                      //S'il clique sur yes
                      if(confirm("Voulez vous vraiment Supprimé cette Annonce ? "))
                      {
                      	supprimer_annonce($(this));

                      	$(this).parent().parent().parent().parent().parent().fadeOut(1500);
                      }

                    });
        });
</script>

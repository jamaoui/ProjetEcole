function lien_active()
{
	var title=location.href.substring(location.href.lastIndexOf("/")+1,location.href.length-4);

	//SI LE TITRE EST VIDE EXEMPLE : X....../ sans le index.php
	if(title=='age/')
		title="index";
	
    $("#"+title).addClass("active_lien");
    $("#"+title).css("border-color","purple");
}